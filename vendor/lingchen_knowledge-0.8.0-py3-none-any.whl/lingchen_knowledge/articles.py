"""Shared article extraction for library links and creation references."""
from __future__ import annotations

import json
import re
import unicodedata
from datetime import datetime
from html.parser import HTMLParser
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

from .links import LinkReadError

_ACCESS_BLOCK_MARKERS = (
    "环境异常", "访问过于频繁", "请完成验证", "该内容已被发布者删除",
    "此内容因违规无法查看", "参数错误",
)

class _ArticleTextParser(HTMLParser):
    _SKIP = {
        "script",
        "style",
        "noscript",
        "iframe",
        "object",
        "embed",
        "form",
        "button",
        "input",
        "textarea",
        "select",
        "svg",
        "canvas",
        "template",
        "nav",
        "header",
        "footer",
        "aside",
    }
    _BLOCK = {"h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "blockquote", "pre", "br"}
    _VOID = {
        "area",
        "base",
        "br",
        "col",
        "embed",
        "hr",
        "img",
        "input",
        "link",
        "meta",
        "param",
        "source",
        "track",
        "wbr",
    }

    def __init__(self, content_id: str | None = None) -> None:
        super().__init__(convert_charrefs=True)
        self.content_id = content_id
        self.skip_depth = 0
        self.body_depth = 0
        self.priority_depth = 0
        self.article_depth = 0
        self.article_seen = False
        self.selected_depth = 0
        self.title_depth = 0
        self.title_parts: list[str] = []
        self.og_title = ""
        self.meta: dict[str, str] = {}
        self.article_metadata: dict[str, str] = {}
        self.metadata_field = ""
        self.metadata_depth = 0
        self.body_parts: list[str] = []
        self.priority_parts: list[str] = []
        self.article_parts: list[str] = []
        self.selected_parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        normalized = tag.lower()
        attributes = {key.lower(): value or "" for key, value in attrs}
        if normalized == "meta" and attributes.get("property", "").lower() == "og:title":
            self.og_title = attributes.get("content", "")
        if normalized == "meta":
            name = attributes.get("property") or attributes.get("name", "")
            self.meta[name.lower()] = attributes.get("content", "")
        # 正文容器内的推广二维码和“问 AI”推荐也须连同其子节点一起排除。
        classes = attributes.get("class", "").split()
        page_widget = (self.content_id == "artibody" and "appendQr_wrap" in classes) or (
            self.content_id == "article-content" and "ac-ask-ai" in classes
        ) or (
            self.content_id == "artiCon" and (
                attributes.get("id") == "js_continue_read_btn"
                or re.search(r"display\s*:\s*none", attributes.get("style", ""), re.I)
            )
        )
        if self.skip_depth or normalized in self._SKIP or page_widget:
            if normalized not in self._VOID:
                self.skip_depth += 1
            return
        if self.content_id == "artiCon" and not self.metadata_depth:
            fields = {"artiTit": "title", "artiSource": "publisher", "artiTime": "publishedAt"}
            self.metadata_field = next((fields[name] for name in classes if name in fields), "")
        if self.metadata_field and normalized not in self._VOID:
            self.metadata_depth += 1
        if normalized == "body":
            self.body_depth += 1
        if normalized in {"main", "article"}:
            self.priority_depth += 1
        if normalized == "article":
            self.article_seen = True
            self.article_depth += 1
        if normalized not in self._VOID and (
            self.selected_depth or (self.content_id and attributes.get("id") == self.content_id)
        ):
            self.selected_depth += 1
        if normalized == "title":
            self.title_depth += 1
        if normalized in self._BLOCK:
            self._append("\n")

    def handle_endtag(self, tag: str) -> None:
        normalized = tag.lower()
        if self.skip_depth:
            if normalized not in self._VOID:
                self.skip_depth -= 1
            return
        if self.metadata_depth and normalized not in self._VOID:
            self.metadata_depth -= 1
            if not self.metadata_depth:
                self.metadata_field = ""
        if normalized in self._BLOCK:
            self._append("\n")
        if normalized == "title" and self.title_depth:
            self.title_depth -= 1
        if normalized in {"main", "article"} and self.priority_depth:
            self.priority_depth -= 1
        if normalized == "article" and self.article_depth:
            self.article_depth -= 1
        if normalized == "body" and self.body_depth:
            self.body_depth -= 1
        if self.selected_depth and normalized not in self._VOID:
            self.selected_depth -= 1

    def handle_data(self, data: str) -> None:
        if self.skip_depth:
            return
        if self.metadata_field:
            self.article_metadata[self.metadata_field] = (
                self.article_metadata.get(self.metadata_field, "") + data
            )
        if self.title_depth:
            self.title_parts.append(data)
        self._append(data)

    def _append(self, value: str) -> None:
        if self.body_depth:
            self.body_parts.append(value)
        if self.priority_depth:
            self.priority_parts.append(value)
        if self.article_depth:
            self.article_parts.append(value)
        if self.selected_depth:
            self.selected_parts.append(value)


def _extract_article(html: str, url: str) -> tuple[str, str]:
    title, content, _ = extract_article(html, url)
    return title, content


def extract_article(html: str, url: str) -> tuple[str, str, dict[str, str]]:
    hostname = (urlsplit(url).hostname or "").lower()
    content_id = {
        "finance.sina.com.cn": "artibody",
        "mp.weixin.qq.com": "js_content",
        "news.qq.com": "article-content",
        "3g.china.com": "artiCon",
    }.get(hostname)
    parser = _ArticleTextParser(content_id)
    parser.feed(html)
    parser.close()
    title = _normalize_inline(
        parser.article_metadata.get("title") or parser.og_title or "".join(parser.title_parts)
    )[:500]
    if (urlsplit(url).hostname or "").lower().endswith("xiaohongshu.com"):
        # XHS renders application navigation and footer text around every note.
        # Only its note-detail state is the source body; accepting the full page
        # would let chrome text masquerade as a verified article.
        note_title, content = _extract_xiaohongshu_note(html, title, url)
        return note_title, content, {}
    # 已知正文容器缺失或为空时不能退回整页；article 也应优先于外围 main。
    parts = parser.article_parts if parser.article_seen else parser.priority_parts
    content = _normalize_blocks("".join(parser.selected_parts if content_id else parts))
    if (urlsplit(url).hostname or "").lower() == "mp.weixin.qq.com":
        inline_body = _normalize_inline("".join(parser.body_parts))
        if any(
            marker in title or (len(inline_body) <= 2_000 and marker in inline_body)
            for marker in _ACCESS_BLOCK_MARKERS
        ):
            raise LinkReadError("access_blocked")
    metadata = {}
    published = parser.meta.get("article:published_time")
    if hostname == "finance.sina.com.cn":
        # 新浪 article:published_time 可能是更新时间；首发时间与页面日期栏一致。
        published = parser.meta.get("bytedance:published_time") or published
        publisher = _normalize_inline(parser.meta.get("article:author", ""))[:200]
        if publisher:
            metadata["publisher"] = publisher
    if hostname == "3g.china.com":
        publisher = _normalize_inline(parser.article_metadata.get("publisher", ""))[:200]
        if publisher:
            metadata["publisher"] = publisher
        raw_date = _normalize_inline(parser.article_metadata.get("publishedAt", ""))
        try:
            instant = datetime.fromisoformat(raw_date)
            published = (
                instant if instant.tzinfo else instant.replace(tzinfo=ZoneInfo("Asia/Shanghai"))
            ).isoformat()
        except ValueError:
            # 页面未提供可识别时间时留空，由调用方保留搜索来源时间。
            published = None
    if published:
        metadata["publishedAt"] = published[:100]
    return title, content, metadata


def read_xiaohongshu_state(html: str) -> dict[str, object]:
    marker = "window.__INITIAL_STATE__="
    start = html.find(marker)
    end = html.find("</script>", start + len(marker)) if start >= 0 else -1
    if start < 0 or end < 0:
        return {}
    state = html[start + len(marker) : end].strip().rstrip(";")
    # 页面状态不是纯 JSON；仅兼容已验证的字面量，原文字符串不能被替换或执行。
    tokens = r'"(?:\\.|[^"\\])*"|(?P<missing>\bundefined\b)|(?P<empty_map>\bnew Map\(\[\]\))'
    state = re.sub(
        tokens,
        lambda match: {"missing": "null", "empty_map": "{}"}.get(
            match.lastgroup, match.group(0)
        ),
        state,
    )
    try:
        payload = json.loads(state)
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def _extract_xiaohongshu_note(
    html: str,
    fallback_title: str,
    url: str,
) -> tuple[str, str]:
    note_state = read_xiaohongshu_state(html).get("note")
    details = note_state.get("noteDetailMap") if isinstance(note_state, dict) else None
    if not isinstance(details, dict):
        return fallback_title, ""
    note_id = urlsplit(url).path.rstrip("/").rsplit("/", 1)[-1]
    detail = details.get(note_id) if note_id else None
    record = detail.get("note") if isinstance(detail, dict) else None
    if not isinstance(record, dict):
        return fallback_title, ""
    title = _normalize_inline(str(record.get("title") or fallback_title))[:500]
    description = str(record.get("desc") or "").replace("[话题]", "")
    # In XHS note state a single newline is authored as a paragraph boundary.
    # Preserve that structure for the existing complete-article gate instead of
    # treating the application payload as one long synthetic paragraph.
    paragraphs = [_normalize_inline(part) for part in re.split(r"\r?\n+", description)]
    return title, _normalize_blocks("\n\n".join(part for part in paragraphs if part))


def _normalize_inline(value: str) -> str:
    normalized = unicodedata.normalize("NFC", value).replace("\x00", "").replace("\xa0", " ")
    return re.sub(r"\s+", " ", normalized).strip()


def _normalize_blocks(value: str) -> str:
    normalized = (
        unicodedata.normalize("NFC", value)
        .replace("\x00", "")
        .replace("\xa0", " ")
        .replace("\r\n", "\n")
        .replace("\r", "\n")
    )
    normalized = re.sub(r"[^\S\n]+", " ", normalized)
    normalized = re.sub(r" *\n *", "\n", normalized)
    return re.sub(r"\n{3,}", "\n\n", normalized).strip()




def extract_link_content(text: str, mime_type: str, final_url: str) -> tuple[str, str, dict[str, str]]:
    """One normalization path for HTML, plain text, Markdown and JSON link sources."""
    if "html" in mime_type:
        return extract_article(text, final_url)
    return "", _normalize_blocks(text), {}
