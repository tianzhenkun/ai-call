"""Canonical material admission and ready-selection contract for every host."""
from __future__ import annotations

from .links import LinkPolicy
from .materials import MaterialResult
from .models import KnowledgeError

MATERIAL_LINK_POLICY = LinkPolicy(
    schemes=frozenset({"http", "https"}),
    allowed_mime=frozenset({"text/html", "application/xhtml+xml", "application/json"}),
    allow_any_text=True,
    require_global_ip=True,
    max_redirects=3,
    max_bytes=2 * 1024 * 1024,
    timeout_seconds=25,
    request_timeout_seconds=12,
    connect_timeout_seconds=5,
    dns_timeout_seconds=5,
    allow_compression=True,
)


def ready_material(
    *, source_id: str, name: str, status: str, text: str | None, parser_version: str,
) -> MaterialResult:
    """Hosts authorize the source first; all consumers enforce the same readiness."""
    if status != "ready" or not text or not text.strip():
        raise KnowledgeError("KNOWLEDGE_UNAVAILABLE", "所选资料无法读取或尚未解析完成")
    return MaterialResult.ready(
        source_id=source_id, name=name, parser_version=parser_version, text=text,
    )
