"""Private, bounded local storage for the reference environment."""

import asyncio
import os
import re
import tempfile
from pathlib import Path

from lingchen_knowledge.content import digest
from lingchen_knowledge.models import KnowledgeError, Original


class LocalOriginals:
    def __init__(self, root: Path):
        self.root = root

    def path(self, tenant_id: str, original: Original) -> Path:
        if not re.fullmatch(r"[0-9a-f]{32}-[0-9a-f]{64}", original.ref):
            raise KnowledgeError("INVALID_FILE_REF", "原件标识无效")
        return self.root / digest(tenant_id.encode()) / original.ref

    async def put(self, tenant_id: str, original: Original, content: bytes) -> str:
        destination = self.path(tenant_id, original)

        def persist():
            destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=destination.parent) as temporary:
                temporary.write(content)
                temporary.flush()
                os.fsync(temporary.fileno())
                try:
                    os.link(temporary.name, destination)
                except FileExistsError:
                    with destination.open("rb") as saved:
                        raw = saved.read(original.size_bytes + 1)
                    if (
                        len(raw) != original.size_bytes
                        or digest(raw) != original.sha256
                    ):
                        raise KnowledgeError(
                            "ORIGINAL_CHECKSUM_MISMATCH", "原件校验失败"
                        )

        await asyncio.to_thread(persist)
        return original.ref

    async def read(self, tenant_id: str, original: Original) -> bytes:
        path = self.path(tenant_id, original)

        def read():
            with path.open("rb") as source:
                return source.read(original.size_bytes + 1)

        return await asyncio.to_thread(read)
