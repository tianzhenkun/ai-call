"""Bounded original reads after the host has obtained an authorized storage URL."""
from __future__ import annotations

import httpx

from ..formats import classify
from ..models import KnowledgeError


async def read_original_url(client: httpx.AsyncClient, url: str, filename: str) -> bytes:
    """The host supplies a trusted signed URL; policy owns the per-format byte gate."""
    maximum = classify(filename).max_bytes
    try:
        async with client.stream("GET", url, follow_redirects=False) as response:
            if response.status_code in {404, 410}:
                raise KnowledgeError("ORIGINAL_NOT_FOUND", "原文件已不存在，请重新上传")
            if not 200 <= response.status_code < 300:
                raise KnowledgeError("ORIGINAL_UNAVAILABLE", "原文件读取失败，请稍后重试", retryable=True)
            declared = response.headers.get("content-length")
            if declared is not None:
                try:
                    size = int(declared)
                except ValueError as exc:
                    raise KnowledgeError("INVALID_ORIGINAL", "原文件大小响应无效") from exc
                if size < 0:
                    raise KnowledgeError("INVALID_ORIGINAL", "原文件大小响应无效")
                if size > maximum:
                    raise KnowledgeError("FILE_TOO_LARGE", "原文件大小超过允许上限")
            content = bytearray()
            async for chunk in response.aiter_bytes():
                if len(content) + len(chunk) > maximum:
                    raise KnowledgeError("FILE_TOO_LARGE", "原文件大小超过允许上限")
                content.extend(chunk)
            if not content:
                raise KnowledgeError("EMPTY_FILE", "原文件为空")
            return bytes(content)
    except httpx.HTTPError as exc:
        raise KnowledgeError("ORIGINAL_UNAVAILABLE", "原文件读取失败，请稍后重试", retryable=True) from exc
