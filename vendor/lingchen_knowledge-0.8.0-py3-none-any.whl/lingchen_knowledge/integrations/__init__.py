"""Optional adapters with explicit host configuration."""
