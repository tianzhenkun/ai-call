"""Reference repository for the four-table schema. The host owns migrations and connections."""

import json
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import replace
from datetime import datetime
from uuid import uuid4

import asyncpg

from lingchen_knowledge.models import (
    Access,
    Chunk,
    Claim,
    Content,
    Item,
    KnowledgeError,
    MediaType,
    Original,
    Page,
    Selection,
    Status,
    UploadRecord,
)

_FIELDS = """
    i.*, t.process_status, t.error_code, t.error_message, t.retryable,
    (t.process_status IN ('pending', 'processing')
        AND (t.next_run_at IS NOT NULL OR t.lease_token IS NOT NULL)) AS poll
"""
_JOIN = """
    FROM knowledge_item i JOIN knowledge_parse_task t
      ON t.tenant_id = i.tenant_id AND t.item_id = i.id
"""
_VISIBLE = """
    i.tenant_id = $1 AND i.deleted_at IS NULL AND (
        (i.access_scope = 'user' AND i.owner_user_id = $2)
        OR (i.access_scope = 'workspace_user' AND i.owner_user_id = $2 AND i.workspace_id = $3)
        OR (i.access_scope = 'tenant' AND $4::boolean)
    )
"""
_CURRENT = """
    tenant_id = $1 AND item_id = $2 AND run_no = $3 AND lease_token = $4
    AND process_status = 'processing' AND lease_expires_at > clock_timestamp()
"""
ReferenceCheck = Callable[[asyncpg.Connection, str, str], Awaitable[bool]]


def _access_args(access: Access) -> tuple:
    return access.tenant_id, access.user_id, access.workspace_id, access.read_shared


def _claim_args(claim: Claim) -> tuple:
    return claim.item.tenant_id, claim.item.id, claim.run_no, claim.token


def _missing() -> KnowledgeError:
    return KnowledgeError("KNOWLEDGE_UNAVAILABLE", "资料不存在或当前无法读取")


def _item(row: asyncpg.Record) -> Item:
    original = Original(
        row["file_ref"],
        row["original_filename"],
        row["mime_type"],
        row["size_bytes"],
        row["file_sha256"],
    )
    return Item(
        id=row["id"],
        tenant_id=row["tenant_id"],
        scope=row["access_scope"],
        owner_user_id=row["owner_user_id"],
        workspace_id=row["workspace_id"],
        name=row["name"],
        media_type=row["media_type"],
        category=row["category_code"],
        note=row["note"],
        original=original,
        status=row["process_status"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        error_code=row["error_code"],
        error_message=row["error_message"],
        retryable=row["retryable"],
        poll=row["poll"],
    )


class PostgresRepository:
    def __init__(
        self, pool: asyncpg.Pool, *, has_reference: ReferenceCheck | None = None
    ):
        self.pool = pool
        self.has_reference = has_reference

    async def _get(
        self,
        conn: asyncpg.Connection,
        access: Access,
        item_id: str,
        *,
        manage: bool = False,
    ) -> Item:
        lock = "FOR UPDATE OF i" if manage else ""
        row = await conn.fetchrow(
            f"SELECT {_FIELDS} {_JOIN} WHERE {_VISIBLE} AND i.id = $5 {lock}",
            *_access_args(access),
            item_id,
        )
        if row is None or (
            manage and row["access_scope"] == "tenant" and not access.manage_shared
        ):
            raise _missing()
        return _item(row)

    async def accept_upload(
        self,
        access: Access,
        record: UploadRecord,
        persist: Callable[[], Awaitable[str]],
    ) -> Item:
        async with self.pool.acquire() as conn, conn.transaction():
            # The lock and unique index cover all concurrent deliveries of the same command.
            key = json.dumps([access.tenant_id, access.user_id, record.key])
            await conn.execute(
                "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))", key
            )
            existing = await conn.fetchrow(
                """
                SELECT id, upload_fingerprint, deleted_at FROM knowledge_item
                WHERE tenant_id = $1 AND created_by = $2 AND upload_key = $3
                """,
                access.tenant_id,
                access.user_id,
                record.key,
            )
            if existing:
                if existing["upload_fingerprint"] != record.fingerprint:
                    raise KnowledgeError(
                        "UPLOAD_CONFLICT", "该上传编号已用于其他文件或设置"
                    )
                if existing["deleted_at"] is not None:
                    raise KnowledgeError(
                        "UPLOAD_ALREADY_DELETED", "这次上传的资料已经删除"
                    )
                return await self._get(conn, access, existing["id"])

            ref = await persist()
            if not ref or len(ref) > 1024:
                raise KnowledgeError(
                    "INVALID_FILE_REF", "文件服务没有返回有效的原件标识"
                )
            await conn.execute(
                """
                INSERT INTO knowledge_item (
                    tenant_id, id, access_scope, workspace_id, owner_user_id, created_by,
                    name, media_type, category_code, note, file_ref, original_filename,
                    mime_type, size_bytes, file_sha256, upload_key, upload_fingerprint
                )
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
                """,
                access.tenant_id,
                record.item_id,
                record.scope,
                record.workspace_id,
                None if record.scope == "tenant" else access.user_id,
                access.user_id,
                record.name,
                record.media_type,
                record.category,
                record.note,
                ref,
                record.original.filename,
                record.original.mime_type,
                record.original.size_bytes,
                record.original.sha256,
                record.key,
                record.fingerprint,
            )
            await conn.execute(
                """
                INSERT INTO knowledge_parse_task (tenant_id, item_id, next_run_at)
                VALUES ($1, $2, clock_timestamp())
                """,
                access.tenant_id,
                record.item_id,
            )
            return await self._get(conn, access, record.item_id)

    async def list_items(
        self,
        access: Access,
        *,
        media_type: MediaType | None,
        category: str | None,
        search: str,
        limit: int,
        offset: int,
    ) -> Page:
        filters = f"""
            WHERE {_VISIBLE}
              AND ($5::text IS NULL OR i.media_type = $5)
              AND ($6::text IS NULL OR i.category_code = $6)
              AND ($7::text = '' OR strpos(lower(i.name), lower($7)) > 0
                 OR strpos(lower(coalesce(i.note, '')), lower($7)) > 0
                 OR (t.process_status = 'ready' AND EXISTS (
                    SELECT 1 FROM knowledge_content c WHERE c.tenant_id = i.tenant_id
                    AND c.item_id = i.id AND strpos(lower(c.body_text), lower($7)) > 0
                 )))
        """
        args = (*_access_args(access), media_type, category, search)
        async with (
            self.pool.acquire() as conn,
            conn.transaction(isolation="repeatable_read", readonly=True),
        ):
            total = await conn.fetchval(f"SELECT count(*) {_JOIN} {filters}", *args)
            rows = await conn.fetch(
                f"""SELECT {_FIELDS} {_JOIN} {filters}
                    ORDER BY i.created_at DESC, i.id DESC LIMIT $8 OFFSET $9""",
                *args,
                limit,
                offset,
            )
        return Page(tuple(_item(row) for row in rows), total)

    async def get_item(self, access: Access, item_id: str) -> Item:
        async with self.pool.acquire() as conn:
            return await self._get(conn, access, item_id)

    async def update_item(
        self,
        access: Access,
        item_id: str,
        fields: dict[str, str | None],
        *,
        expected_updated_at: datetime | None,
    ) -> Item:
        async with self.pool.acquire() as conn, conn.transaction():
            item = await self._get(conn, access, item_id, manage=True)
            if (
                expected_updated_at is not None
                and item.updated_at != expected_updated_at
            ):
                raise KnowledgeError("UPDATE_CONFLICT", "资料已更新，请刷新后重试")
            await conn.execute(
                """
                UPDATE knowledge_item SET name = $3, category_code = $4, note = $5,
                    updated_at = clock_timestamp()
                WHERE tenant_id = $1 AND id = $2
                """,
                access.tenant_id,
                item_id,
                fields.get("name", item.name),
                fields.get("category", item.category),
                fields.get("note", item.note),
            )
            return await self._get(conn, access, item_id)

    async def read_ready(
        self, access: Access, ids: Sequence[str]
    ) -> tuple[Selection, ...]:
        async with (
            self.pool.acquire() as conn,
            conn.transaction(isolation="repeatable_read", readonly=True),
        ):
            rows = await conn.fetch(
                f"""SELECT {_FIELDS}, c.body_text, c.body_sha256, c.parser_version, c.chunker_version
                    {_JOIN} JOIN knowledge_content c ON c.tenant_id = i.tenant_id AND c.item_id = i.id
                    WHERE {_VISIBLE} AND t.process_status = 'ready' AND i.id = ANY($5::varchar[])""",
                *_access_args(access),
                list(ids),
            )
            if len(rows) != len(ids):
                raise _missing()
            by_id = {row["id"]: row for row in rows}
            chunks = {item_id: [] for item_id in ids}
            records = await conn.fetch(
                """SELECT * FROM knowledge_chunk WHERE tenant_id = $1 AND item_id = ANY($2::varchar[])
                   ORDER BY item_id, ordinal""",
                access.tenant_id,
                list(ids),
            )
            for record in records:
                chunks[record["item_id"]].append(
                    Chunk(
                        record["ordinal"],
                        record["chunk_text"],
                        record["chunk_sha256"],
                        json.loads(record["locator_json"])
                        if record["locator_json"]
                        else {},
                    )
                )
        result = []
        for item_id in ids:
            row = by_id[item_id]
            if not chunks[item_id]:
                raise _missing()
            result.append(
                Selection(
                    _item(row),
                    Content(
                        row["body_text"],
                        row["body_sha256"],
                        row["parser_version"],
                        row["chunker_version"],
                        tuple(chunks[item_id]),
                    ),
                )
            )
        return tuple(result)

    async def lock_ready_for_reference(
        self,
        conn: asyncpg.Connection,
        access: Access,
        item_ids: Sequence[str],
    ) -> None:
        """Host reference writers call this in the same transaction as their insert."""
        if not conn.is_in_transaction():
            raise RuntimeError("Reference writes require a transaction")
        ids = sorted(set(item_ids))
        if not 1 <= len(ids) <= 50:
            raise KnowledgeError("INVALID_SELECTION", "请选择 1 至 50 份资料")
        rows = await conn.fetch(
            f"""SELECT i.id FROM knowledge_item i WHERE {_VISIBLE}
                AND i.id = ANY($5::varchar[]) ORDER BY i.id FOR UPDATE OF i""",
            *_access_args(access),
            ids,
        )
        if len(rows) != len(ids):
            raise _missing()
        ready = await conn.fetchval(
            """SELECT count(*) FROM knowledge_parse_task
               WHERE tenant_id = $1 AND item_id = ANY($2::varchar[]) AND process_status = 'ready'""",
            access.tenant_id,
            ids,
        )
        if ready != len(ids):
            raise _missing()

    async def delete(self, access: Access, item_id: str) -> None:
        async with self.pool.acquire() as conn, conn.transaction():
            await self._get(conn, access, item_id, manage=True)
            if self.has_reference is None:
                raise KnowledgeError(
                    "REFERENCE_CHECK_UNAVAILABLE", "暂时无法确认资料引用"
                )
            if await self.has_reference(conn, access.tenant_id, item_id):
                raise KnowledgeError("KNOWLEDGE_IN_USE", "已有引用 无法删除")
            await conn.execute(
                """UPDATE knowledge_item SET deleted_at = clock_timestamp()
                   WHERE tenant_id = $1 AND id = $2""",
                access.tenant_id,
                item_id,
            )
            await conn.execute(
                """UPDATE knowledge_parse_task
                   SET lease_token = NULL, lease_expires_at = NULL, next_run_at = NULL
                   WHERE tenant_id = $1 AND item_id = $2""",
                access.tenant_id,
                item_id,
            )

    async def retry(self, access: Access, item_id: str) -> Item:
        async with self.pool.acquire() as conn, conn.transaction():
            await self._get(conn, access, item_id, manage=True)
            updated = await conn.fetchval(
                """
                UPDATE knowledge_parse_task SET
                    process_status = CASE WHEN provider_job_id IS NULL THEN 'pending' ELSE 'processing' END,
                    provider_state = CASE WHEN provider_job_id IS NULL THEN NULL ELSE 'submitted' END,
                    provider_name = CASE WHEN provider_job_id IS NULL THEN NULL ELSE provider_name END,
                    provider_request_key = CASE WHEN provider_job_id IS NULL THEN NULL ELSE provider_request_key END,
                    provider_started_at = CASE WHEN provider_job_id IS NULL THEN NULL ELSE clock_timestamp() END,
                    run_no = run_no + 1, attempt_count = 0, next_run_at = clock_timestamp(),
                    error_code = NULL, error_message = NULL, retryable = FALSE, updated_at = clock_timestamp()
                WHERE tenant_id = $1 AND item_id = $2 AND process_status = 'failed' AND retryable
                RETURNING item_id
                """,
                access.tenant_id,
                item_id,
            )
            if not updated:
                raise KnowledgeError("NOT_RETRYABLE", "当前资料无法重新解析")
            return await self._get(conn, access, item_id)

    async def claim(self, *, lease_seconds: float) -> Claim | None:
        async with self.pool.acquire() as conn, conn.transaction():
            row = await conn.fetchrow(
                f"""SELECT {_FIELDS}, t.run_no, t.provider_name, t.provider_state,
                           t.provider_request_key, t.provider_job_id, t.provider_started_at
                    {_JOIN} WHERE i.deleted_at IS NULL AND t.process_status IN ('pending', 'processing')
                    AND (t.next_run_at <= clock_timestamp() OR t.lease_expires_at <= clock_timestamp())
                    ORDER BY coalesce(t.next_run_at, t.lease_expires_at), i.tenant_id, i.id
                    FOR UPDATE OF t SKIP LOCKED LIMIT 1"""
            )
            if row is None:
                return None
            token = uuid4().hex
            attempt = await conn.fetchval(
                """
                UPDATE knowledge_parse_task SET process_status = 'processing', next_run_at = NULL,
                    lease_token = $3, lease_expires_at = clock_timestamp() + $4 * interval '1 second',
                    attempt_count = attempt_count + 1, updated_at = clock_timestamp()
                WHERE tenant_id = $1 AND item_id = $2 RETURNING attempt_count
                """,
                row["tenant_id"],
                row["id"],
                token,
                lease_seconds,
            )
            return Claim(
                replace(_item(row), status="processing", poll=True),
                row["run_no"],
                token,
                attempt,
                row["provider_name"],
                row["provider_state"],
                row["provider_request_key"],
                row["provider_job_id"],
                row["provider_started_at"],
            )

    async def _lock_active(
        self, conn: asyncpg.Connection, tenant_id: str, item_id: str
    ) -> bool:
        return bool(
            await conn.fetchval(
                """SELECT TRUE FROM knowledge_item WHERE tenant_id = $1 AND id = $2
               AND deleted_at IS NULL FOR UPDATE""",
                tenant_id,
                item_id,
            )
        )

    async def remember_provider(
        self,
        claim: Claim,
        *,
        name: str,
        request_key: str,
        job_id: str | None,
    ) -> bool:
        async with self.pool.acquire() as conn, conn.transaction():
            if not await self._lock_active(conn, claim.item.tenant_id, claim.item.id):
                return False
            return bool(
                await conn.fetchval(
                    f"""
                UPDATE knowledge_parse_task SET provider_name = $5, provider_request_key = $6,
                    provider_job_id = $7, provider_started_at = coalesce(provider_started_at, clock_timestamp()),
                    provider_state = CASE WHEN $7::varchar IS NULL THEN 'unknown' ELSE 'submitted' END,
                    updated_at = clock_timestamp()
                WHERE {_CURRENT} AND (provider_name IS NULL OR
                    (provider_name = $5 AND provider_request_key = $6 AND
                     (provider_job_id IS NULL OR provider_job_id = $7)))
                RETURNING item_id
                """,
                    *_claim_args(claim),
                    name,
                    request_key,
                    job_id,
                )
            )

    async def release(
        self,
        claim: Claim,
        *,
        status: Status,
        delay: float | None,
        error: KnowledgeError | None = None,
        clear_provider: bool = False,
        reset_attempts: bool = False,
    ) -> bool:
        async with self.pool.acquire() as conn, conn.transaction():
            if not await self._lock_active(conn, claim.item.tenant_id, claim.item.id):
                return False
            return bool(
                await conn.fetchval(
                    f"""
                UPDATE knowledge_parse_task SET process_status = $5,
                    next_run_at = clock_timestamp() + $6::double precision * interval '1 second',
                    lease_token = NULL, lease_expires_at = NULL, error_code = $7, error_message = $8,
                    retryable = $9, provider_name = CASE WHEN $10 THEN NULL ELSE provider_name END,
                    provider_request_key = CASE WHEN $10 THEN NULL ELSE provider_request_key END,
                    provider_job_id = CASE WHEN $10 THEN NULL ELSE provider_job_id END,
                    provider_started_at = CASE WHEN $10 THEN NULL ELSE provider_started_at END,
                    provider_state = CASE WHEN $10 THEN NULL
                        WHEN $5::varchar = 'failed' AND provider_state IS NOT NULL THEN 'resolved'
                        ELSE provider_state END,
                    attempt_count = CASE WHEN $11 THEN 0 ELSE attempt_count END,
                    updated_at = clock_timestamp()
                WHERE {_CURRENT} RETURNING item_id
                """,
                    *_claim_args(claim),
                    status,
                    delay,
                    error.code if error else None,
                    str(error) if error else None,
                    status == "failed" and bool(error and error.retryable),
                    clear_provider,
                    reset_attempts,
                )
            )

    async def complete(self, claim: Claim, content: Content) -> bool:
        async with self.pool.acquire() as conn, conn.transaction():
            if not await self._lock_active(conn, claim.item.tenant_id, claim.item.id):
                return False
            ready = await conn.fetchval(
                f"""
                UPDATE knowledge_parse_task SET process_status = 'ready',
                    lease_token = NULL, lease_expires_at = NULL, next_run_at = NULL,
                    error_code = NULL, error_message = NULL, retryable = FALSE, updated_at = clock_timestamp(),
                    provider_state = CASE WHEN provider_state IS NULL THEN NULL ELSE 'resolved' END
                WHERE {_CURRENT} RETURNING item_id
                """,
                *_claim_args(claim),
            )
            if not ready:
                return False
            await conn.execute(
                """
                INSERT INTO knowledge_content (tenant_id, item_id, body_text, body_sha256, parser_version, chunker_version)
                VALUES ($1, $2, $3, $4, $5, $6)
                """,
                claim.item.tenant_id,
                claim.item.id,
                content.text,
                content.sha256,
                content.parser_version,
                content.chunker_version,
            )
            await conn.executemany(
                """
                INSERT INTO knowledge_chunk (tenant_id, item_id, ordinal, chunk_text, chunk_sha256, locator_json)
                VALUES ($1, $2, $3, $4, $5, $6)
                """,
                [
                    (
                        claim.item.tenant_id,
                        claim.item.id,
                        chunk.ordinal,
                        chunk.text,
                        chunk.sha256,
                        json.dumps(chunk.locator),
                    )
                    for chunk in content.chunks
                ],
            )
            return True

    async def resolve_unknown(
        self,
        tenant_id: str,
        item_id: str,
        request_key: str,
        *,
        job_id: str | None,
    ) -> bool:
        """Trusted operator only. A missing job ID means the provider confirmed no submission."""
        if job_id is not None and (not job_id.strip() or len(job_id) > 128):
            raise ValueError("Invalid provider job ID")
        async with self.pool.acquire() as conn, conn.transaction():
            if not await self._lock_active(conn, tenant_id, item_id):
                return False
            return bool(
                await conn.fetchval(
                    """
                UPDATE knowledge_parse_task SET
                    provider_name = CASE WHEN $4::varchar IS NULL THEN NULL ELSE provider_name END,
                    provider_request_key = CASE WHEN $4::varchar IS NULL THEN NULL ELSE provider_request_key END,
                    provider_started_at = CASE WHEN $4::varchar IS NULL THEN NULL ELSE clock_timestamp() END,
                    provider_state = CASE WHEN $4::varchar IS NULL THEN NULL ELSE 'submitted' END,
                    provider_job_id = $4, process_status = CASE WHEN $4::varchar IS NULL THEN 'pending' ELSE 'processing' END,
                    run_no = CASE WHEN $4::varchar IS NULL THEN run_no + 1 ELSE run_no END,
                    next_run_at = clock_timestamp(), attempt_count = 0,
                    error_code = NULL, error_message = NULL, updated_at = clock_timestamp()
                WHERE tenant_id = $1 AND item_id = $2 AND provider_request_key = $3
                  AND provider_state = 'unknown' AND process_status = 'processing'
                  AND next_run_at IS NULL AND lease_token IS NULL
                RETURNING item_id
                """,
                    tenant_id,
                    item_id,
                    request_key,
                    job_id,
                )
            )
