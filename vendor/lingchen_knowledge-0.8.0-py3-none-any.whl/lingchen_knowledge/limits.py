"""Single source of truth for intake, library and creation limits.

Every product (geo, leads, sales) reads these values instead of hard-coding its
own. The three layers are deliberately coupled:

* Intake decides what may be accepted (bytes, formats, batch size).
* Parsing decides how much正文 may be stored (characters, not bytes).
* Creation decides how much正文 one generation may consume.

Bytes never translate into characters: a 50 MB PDF can hold 3 million
characters or none at all, so the business bound is always expressed in
characters and the byte limit only protects memory and storage.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

MIB = 1024 * 1024


@dataclass(frozen=True, slots=True)
class IntakeLimits:
    """L1 准入：能不能进来。"""

    document_max_bytes: int = 20 * MIB
    image_max_bytes: int = 10 * MIB
    # 音频与视频必须分开：64 MB 的语音是 2 小时（64 kbps），同样体积的视频
    # 只有约 65 秒。同一档上限会让「传会议录像」永远失败。
    # 取 64 MB 而不是 50 MB：50 MB 在 64 kbps 下只够 1 小时 49 分，会把
    # media_max_seconds 承诺的「2 小时」提前卡掉；64 MB 与 asr_max_bytes 对齐。
    audio_max_bytes: int = 64 * MIB
    # 200 MB 覆盖手机 1080p 约 2 分钟、720p 约 5.5 分钟、微信压缩后约 18 分钟、
    # 360p 约 56 分钟。仍到不了「2 小时视频」，那需要 200 Mbps 级别的码率空间，
    # 因此视频的时长上限实际由字节决定，2 小时只对音频成立。
    video_max_bytes: int = 200 * MIB
    # 批次只按总字节收口：知识库允许一次传很多小文件，个数不作为硬限制。
    # 必须不小于单文件最大上限，否则「单份能传、一批传不了」自相矛盾。
    batch_max_bytes: int = 200 * MIB
    # 音视频的真实业务上限是时长，不是字节：语音转写后的正文长度由时长决定。
    # 2 小时覆盖单次会议、访谈、电话录音，转写后约 2~3 万字，仍在正文上限之内。
    media_max_seconds: int = 2 * 60 * 60
    # 2 小时 64 kbps 单声道 ≈ 57.6 MB，留余量取 64 MB。低于该值会把长音频截断，
    # 因此字节上限必须不小于时长上限除以码率的结果。
    asr_max_bytes: int = 64 * MIB
    # 正文上限，超过直接报错，不静默截断。
    document_max_chars: int = 200_000
    # 每页少于该字符数即判定为扫描页。
    pdf_scan_min_chars_per_page: int = 20
    # 扫描页占比达到该比例时整份转 OCR，避免文字层与 OCR 结果混杂。
    pdf_scan_page_ratio: float = 0.3
    # 解析结果允许一次转 OCR 的 PDF 体积上限。
    ocr_pdf_max_bytes: int = 50 * MIB


@dataclass(frozen=True, slots=True)
class LibraryLimits:
    """L2 库容量：库里能存多少。"""

    max_items: int = 50
    max_chars: int = 2_000_000


@dataclass(frozen=True, slots=True)
class CreationLimits:
    """L3 消费：一次生成能用多少。"""

    budget_chars: int = 12_000
    fragment_chars: int = 500
    max_fragments: int = 20
    max_file_items: int = 20
    max_knowledge_items: int = 50
    max_link_items: int = 5
    # 产物侧上限：生成或编辑后的正文（文章正文、草稿）长度。
    # 与 INTAKE.document_max_chars 是两个口径：原料可以到 20 万字，
    # 但产物是给人读/继续加工的，再长只会拖垮编辑器与后续翻译、配图。
    content_max_chars: int = 100_000

    @property
    def max_auxiliary_items(self) -> int:
        return (
            self.max_file_items + self.max_knowledge_items + self.max_link_items
        )


INTAKE = IntakeLimits()
LIBRARY = LibraryLimits()
CREATION = CreationLimits()


def carrier_max_bytes(media_type: str) -> int:
    """按载体取字节上限；service.max_file_bytes 是按文件名判定的产品入口。"""
    return {
        "document": INTAKE.document_max_bytes,
        "image": INTAKE.image_max_bytes,
        "audio": INTAKE.audio_max_bytes,
        "video": INTAKE.video_max_bytes,
    }[media_type]


def format_bytes(size: int) -> str:
    """字节文案：报错信息从限制值算出来，不写死 "200 MB" 这种会过期的常量。"""
    total = max(0, int(size))
    if total < 1024:
        return f"{total} B"
    if total < MIB:
        return f"{round(total / 1024)} KB"
    value = total / MIB
    return f"{value:.0f} MB" if value >= 10 else f"{value:.1f}".rstrip("0").rstrip(".") + " MB"


def limits_payload() -> dict:
    """Camel-case payload consumed by both front-ends, so limits live in one place."""
    return {
        "version": 2,
        "intake": {
            "documentMaxBytes": INTAKE.document_max_bytes,
            "imageMaxBytes": INTAKE.image_max_bytes,
            "audioMaxBytes": INTAKE.audio_max_bytes,
            "videoMaxBytes": INTAKE.video_max_bytes,
            "mediaMaxSeconds": INTAKE.media_max_seconds,
            "batchMaxBytes": INTAKE.batch_max_bytes,
            "documentMaxChars": INTAKE.document_max_chars,
        },
        "library": asdict(LIBRARY),
        "creation": {
            "budgetChars": CREATION.budget_chars,
            "fragmentChars": CREATION.fragment_chars,
            "maxFragments": CREATION.max_fragments,
            "maxFileItems": CREATION.max_file_items,
            "maxKnowledgeItems": CREATION.max_knowledge_items,
            "maxLinkItems": CREATION.max_link_items,
            "contentMaxChars": CREATION.content_max_chars,
        },
    }


__all__ = [
    "CREATION",
    "INTAKE",
    "LIBRARY",
    "CreationLimits",
    "IntakeLimits",
    "LibraryLimits",
    "MIB",
    "carrier_max_bytes",
    "format_bytes",
    "limits_payload",
]
