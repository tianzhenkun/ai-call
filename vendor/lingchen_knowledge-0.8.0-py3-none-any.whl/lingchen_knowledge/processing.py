import asyncio
from collections.abc import Mapping
from datetime import UTC, datetime

from .content import build_content, digest
from .documents import PdfNeedsOcr, parse_document_content
from .models import (
    Claim,
    KnowledgeError,
    MediaProvider,
    MediaType,
    Originals,
    Repository,
)


class SubmissionUnknown(KnowledgeError):
    def __init__(self):
        super().__init__("SUBMISSION_UNKNOWN", "解析任务提交结果待核对")


class KnowledgeProcessor:
    """Process a single due step. Hosts own the scheduler and call run_once."""

    def __init__(
        self,
        repository: Repository,
        originals: Originals,
        providers: Mapping[MediaType, MediaProvider] | None = None,
        *,
        step_timeout: float = 60,
        lease_seconds: float = 90,
        poll_interval: float = 2,
        provider_timeout: float = 900,
        max_attempts: int = 3,
    ):
        if (
            not 0 < step_timeout < lease_seconds - 5
            or min(poll_interval, provider_timeout, max_attempts) <= 0
        ):
            raise ValueError("Invalid knowledge processing limits")
        self.repo = repository
        self.originals = originals
        self.providers = dict(providers or {})
        self.step_timeout = step_timeout
        self.lease_seconds = lease_seconds
        self.poll_interval = poll_interval
        self.provider_timeout = provider_timeout
        self.max_attempts = max_attempts

    async def run_once(self) -> bool:
        claim = await self.repo.claim(lease_seconds=self.lease_seconds)
        if claim is None:
            return False
        if claim.attempt > self.max_attempts and claim.provider_state != "unknown":
            await self._failure(
                claim,
                KnowledgeError(
                    "PARSE_INTERRUPTED", "解析多次中断，可重新解析", retryable=True
                ),
                immediate=True,
            )
            return True
        try:
            if claim.item.media_type == "document" and claim.provider_name is None:
                async with asyncio.timeout(self.step_timeout):
                    raw = await self._read(claim)
                    try:
                        content = await parse_document_content(
                            claim.item.original.filename, raw, timeout=self.step_timeout
                        )
                    except PdfNeedsOcr:
                        # A scanned PDF is still a document: fall through to the OCR
                        # provider under the same claim so retries stay idempotent.
                        if "document" not in self.providers:
                            raise KnowledgeError(
                                "OCR_UNAVAILABLE",
                                "扫描版 PDF 需要文字识别，当前未配置识别服务",
                            ) from None
                        raw = b""
                        await self._media(claim)
                        return True
                await self.repo.complete(claim, content)
            else:
                await self._media(claim)
        except KnowledgeError as exc:
            if claim.provider_state == "unknown":
                await self._hold_unknown(claim)
            elif exc.code == "PROVIDER_JOB_EXPIRED":
                await self._failure(claim, exc, clear_provider=True, immediate=True)
            else:
                await self._failure(claim, exc)
        except TimeoutError:
            await self._failure(
                claim, KnowledgeError("PARSE_TIMEOUT", "解析超时", retryable=True)
            )
        except OSError:
            await self._failure(
                claim,
                KnowledgeError(
                    "ORIGINAL_UNAVAILABLE", "暂时无法读取原件", retryable=True
                ),
            )
        return True

    async def _read(self, claim: Claim) -> bytes:
        original = claim.item.original
        content = await self.originals.read(claim.item.tenant_id, original)
        if len(content) != original.size_bytes or digest(content) != original.sha256:
            raise KnowledgeError("ORIGINAL_CHECKSUM_MISMATCH", "原件校验失败")
        return content

    async def _media(self, claim: Claim) -> None:
        provider = self.providers.get(claim.item.media_type)
        if provider is None or (
            claim.provider_name and provider.name != claim.provider_name
        ):
            if claim.provider_state == "unknown":
                await self._hold_unknown(claim, stop=True)
                return
            raise KnowledgeError(
                "PROVIDER_UNAVAILABLE", "解析服务未配置", retryable=True
            )

        if claim.provider_state == "unknown":
            # Never repeat an unconfirmed request. The provider may already be processing it.
            if claim.request_key is None:
                await self._hold_unknown(claim, stop=True)
                return
            try:
                async with asyncio.timeout(self.step_timeout):
                    job_id = await provider.recover(claim.request_key)
            except (TimeoutError, OSError, KnowledgeError):
                job_id = None
            if not job_id:
                await self._hold_unknown(claim)
                return
            if await self.repo.remember_provider(
                claim, name=provider.name, request_key=claim.request_key, job_id=job_id
            ):
                await self._waiting(claim)
            return

        if claim.job_id:
            if (
                claim.provider_started_at
                and (datetime.now(UTC) - claim.provider_started_at).total_seconds()
                >= self.provider_timeout
            ):
                await self._failure(
                    claim,
                    KnowledgeError(
                        "PROVIDER_TIMEOUT",
                        "解析服务等待超时，可继续查询",
                        retryable=True,
                    ),
                    immediate=True,
                )
                return
            async with asyncio.timeout(self.step_timeout):
                parsed = await provider.poll(claim.job_id)
            if parsed is None:
                await self._waiting(claim)
            else:
                await self.repo.complete(claim, build_content(parsed))
            return

        key = f"{claim.item.id}-{claim.run_no}"
        deadline = asyncio.get_running_loop().time() + self.step_timeout
        async with asyncio.timeout_at(deadline):
            raw = await self._read(claim)
            source = await provider.prepare(claim, raw, key)
        if not await self.repo.remember_provider(
            claim, name=provider.name, request_key=key, job_id=None
        ):
            return
        try:
            async with asyncio.timeout_at(deadline):
                job_id = await provider.submit(source, key)
            if not job_id or len(job_id) > 128:
                raise SubmissionUnknown()
        except (SubmissionUnknown, TimeoutError, OSError):
            await self._hold_unknown(claim)
            return
        except KnowledgeError as exc:
            # The adapter only raises other KnowledgeError values for definite rejection.
            await self._failure(claim, exc, clear_provider=True)
            return
        if await self.repo.remember_provider(
            claim, name=provider.name, request_key=key, job_id=job_id
        ):
            await self._waiting(claim)

    async def _waiting(self, claim: Claim) -> None:
        await self.repo.release(
            claim, status="processing", delay=self.poll_interval, reset_attempts=True
        )

    async def _hold_unknown(self, claim: Claim, *, stop: bool = False) -> None:
        delay = (
            None
            if stop or claim.attempt >= self.max_attempts
            else min(60, self.poll_interval * 2**claim.attempt)
        )
        await self.repo.release(
            claim, status="processing", delay=delay, error=SubmissionUnknown()
        )

    async def _failure(
        self,
        claim: Claim,
        error: KnowledgeError,
        *,
        clear_provider: bool = False,
        immediate: bool = False,
    ) -> None:
        again = error.retryable and not immediate and claim.attempt < self.max_attempts
        status = (
            ("processing" if claim.job_id and not clear_provider else "pending")
            if again
            else "failed"
        )
        await self.repo.release(
            claim,
            status=status,
            delay=min(60, 2**claim.attempt) if again else None,
            error=error,
            clear_provider=clear_provider,
        )
