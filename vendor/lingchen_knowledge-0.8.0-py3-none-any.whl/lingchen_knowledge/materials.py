"""Parser output contract; hosts own authorization, persistence and associations."""

from __future__ import annotations

from dataclasses import dataclass

from .content import digest
from .models import Block


@dataclass(frozen=True, slots=True)
class MaterialResult:
    source_id: str
    name: str
    parser_version: str
    text: str
    content_checksum: str | None
    blocks: tuple[Block, ...] = ()
    error_code: str | None = None
    error_message: str | None = None

    @classmethod
    def ready(
        cls, *, source_id: str, name: str, parser_version: str,
        text: str, blocks: tuple[Block, ...] = (),
    ) -> MaterialResult:
        if not source_id or not name or not parser_version or not text.strip():
            raise ValueError("Ready material requires source, name, version and text")
        return cls(source_id, name, parser_version, text, digest(text.encode("utf-8")), blocks)

    @classmethod
    def failed(
        cls, source_id: str, name: str, parser_version: str,
        error_code: str, error_message: str,
    ) -> MaterialResult:
        if not source_id or not name or not parser_version or not error_code or not error_message:
            raise ValueError("Failed material requires source and error")
        return cls(source_id, name, parser_version, "", None, (), error_code, error_message)

    def snapshot(self) -> dict[str, object]:
        blocks = []
        for block in self.blocks:
            item: dict[str, object] = {"text": block.text}
            for key, value in (
                ("page", block.page), ("paragraph", block.paragraph),
                ("startMs", block.start_ms), ("endMs", block.end_ms),
                ("speaker", block.speaker),
            ):
                if value is not None:
                    item[key] = value
            blocks.append(item)
        return {
            "sourceId": self.source_id,
            "name": self.name,
            "parserVersion": self.parser_version,
            "text": self.text,
            "blocks": blocks,
            "contentChecksum": self.content_checksum,
            "error": (
                {"code": self.error_code, "message": self.error_message}
                if self.error_code is not None else None
            ),
        }
