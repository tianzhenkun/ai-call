import asyncio
import io
import json
import math
import multiprocessing
import re
import zipfile
from dataclasses import dataclass, replace
from html.parser import HTMLParser
from pathlib import PurePath
from xml.etree import ElementTree

from pypdf import PdfReader

from .content import MAX_CONTENT_CHARS, format_char_count
from .limits import INTAKE
from .models import Block, KnowledgeError, Parsed

MAX_DOCUMENT_XML = 16 * 1024 * 1024
MAX_PDF_PAGES = 2000
_WORD_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_UNSAFE_DOCX_PREFIXES = ("word/activex/", "word/embeddings/", "customui/")


class PdfNeedsOcr(KnowledgeError):
    """Text layer is absent or too thin; the host must route this PDF to OCR."""

    def __init__(self, pages: tuple[int, ...], page_count: int):
        self.pages = tuple(pages)
        self.page_count = page_count
        preview = "、".join(str(page) for page in self.pages[:5])
        suffix = " 等" if len(self.pages) > 5 else ""
        super().__init__(
            "PDF_NEEDS_OCR",
            f"PDF 第 {preview}{suffix} 页（共 {page_count} 页）为扫描图像，需转文字识别",
        )


@dataclass(frozen=True, slots=True)
class DocumentPolicy:
    max_content_chars: int = MAX_CONTENT_CHARS
    max_pdf_pages: int = MAX_PDF_PAGES
    max_document_xml_bytes: int = MAX_DOCUMENT_XML
    max_docx_entries: int = 1000
    max_docx_uncompressed_bytes: int = 64 * 1024 * 1024
    strict_utf8: bool = False
    strict_pdf: bool = False
    strict_docx_package: bool = False
    preserve_empty_paragraphs: bool = False
    truncate_content: bool = False
    extra_text_formats: frozenset[str] = frozenset({".csv", ".json", ".html", ".htm"})
    # Scanned PDF detection: below this many characters a page counts as an image.
    pdf_scan_min_chars_per_page: int = INTAKE.pdf_scan_min_chars_per_page
    # Whole-document OCR is preferred over mixing text layers, so the trigger is a ratio.
    pdf_scan_page_ratio: float = INTAKE.pdf_scan_page_ratio
    detect_scanned_pdf: bool = True


class _HtmlText(HTMLParser):
    _SKIP = {"script", "style", "noscript", "iframe", "object", "embed", "template"}
    _BLOCK = {"h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "blockquote", "pre", "br"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.depth = 0
        self.parts: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag in self._SKIP:
            self.depth += 1
        elif tag in self._BLOCK:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in self._SKIP and self.depth:
            self.depth -= 1
        elif tag in self._BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.depth:
            self.parts.append(data)


def _paragraph_text(paragraph) -> str:
    pieces = []
    for node in paragraph.iter():
        if node.tag == _WORD_NS + "t":
            pieces.append(node.text or "")
        elif node.tag == _WORD_NS + "tab":
            pieces.append(" ")
        elif node.tag in {_WORD_NS + "br", _WORD_NS + "cr"}:
            pieces.append("\n")
    return "".join(pieces)


def _table_text(table) -> str:
    """Keep row/column relationships: cells joined by `|`, rows by newline."""
    rows: list[str] = []
    for row in table.findall(_WORD_NS + "tr"):
        cells: list[str] = []
        for cell in row.findall(_WORD_NS + "tc"):
            text = " ".join(
                part.replace("\n", " ").strip()
                for part in (_paragraph_text(p) for p in cell.findall(_WORD_NS + "p"))
                if part.strip()
            )
            cells.append(text)
        line = " | ".join(cells)
        if line.strip(" |"):
            rows.append(line)
    return "\n".join(rows)


def _docx_body_children(root) -> list:
    """Flatten content controls so paragraphs and tables stay in document order."""
    body = root.find(_WORD_NS + "body")
    if body is None:
        return []
    children = []
    for child in body:
        if child.tag == _WORD_NS + "sdt":
            content = child.find(_WORD_NS + "sdtContent")
            if content is not None:
                children.extend(list(content))
            continue
        children.append(child)
    return children


def _docx_blocks(raw: bytes, policy: DocumentPolicy):
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        if policy.strict_docx_package:
            entries = archive.infolist()
            if len(entries) > policy.max_docx_entries:
                raise KnowledgeError("DOCUMENT_LIMIT", "Word 文档条目超过解析限制")
            total = 0
            document_count = 0
            content_types = False
            for item in entries:
                name = item.filename
                lowered = name.lower()
                if (not name or "\\" in name or name.startswith("/")
                        or ".." in name.split("/") or item.flag_bits & 1
                        or lowered.endswith("/vbaproject.bin")
                        or lowered == "vbaproject.bin"
                        or lowered.startswith(_UNSAFE_DOCX_PREFIXES)):
                    raise KnowledgeError("INVALID_DOCUMENT", "Word 文档包含不安全条目")
                total += item.file_size
                content_types |= name == "[Content_Types].xml"
                document_count += name == "word/document.xml"
            if total > policy.max_docx_uncompressed_bytes:
                raise KnowledgeError("DOCUMENT_LIMIT", "Word 文档解压后超过解析限制")
            if not content_types or document_count != 1:
                raise KnowledgeError("INVALID_DOCUMENT", "Word 文档缺少必需结构")
        entry = archive.getinfo("word/document.xml")
        if entry.file_size > policy.max_document_xml_bytes:
            raise KnowledgeError("DOCUMENT_LIMIT", "Word 文档内容超过解析限制")
        with archive.open(entry) as stream:
            xml = stream.read(policy.max_document_xml_bytes + 1)
    if len(xml) > policy.max_document_xml_bytes:
        raise KnowledgeError("DOCUMENT_LIMIT", "Word 文档内容超过解析限制")
    decoded = xml.decode("utf-8-sig")
    if re.search(r"<!DOCTYPE|<!ENTITY", decoded, flags=re.I):
        raise KnowledgeError("INVALID_DOCUMENT", "Word 文档结构无效")
    root = ElementTree.fromstring(decoded)
    if policy.strict_docx_package and root.tag != _WORD_NS + "document":
        raise KnowledgeError("INVALID_DOCUMENT", "Word 文档结构无效")
    children = _docx_body_children(root)
    if children:
        number = 0
        for child in children:
            if child.tag == _WORD_NS + "tbl":
                text = _table_text(child)
                if text:
                    yield Block(text)
                continue
            if child.tag != _WORD_NS + "p":
                continue
            number += 1
            text = _paragraph_text(child)
            if text.strip() or policy.preserve_empty_paragraphs:
                yield Block(text, paragraph=number)
        return
    for number, paragraph in enumerate(root.iter(_WORD_NS + "p"), start=1):
        text = _paragraph_text(paragraph)
        if text.strip() or policy.preserve_empty_paragraphs:
            yield Block(text, paragraph=number)


def _pdf_blocks(raw: bytes, policy: DocumentPolicy):
    if policy.strict_pdf and re.search(rb"/Encrypt\s+\d+\s+\d+\s+R\b", raw[-64 * 1024:]):
        raise KnowledgeError("ENCRYPTED_PDF", "请先解除 PDF 密码保护")
    reader = PdfReader(io.BytesIO(raw), strict=policy.strict_pdf)
    if reader.is_encrypted:
        raise KnowledgeError("ENCRYPTED_PDF", "请先解除 PDF 密码保护")
    if len(reader.pages) > policy.max_pdf_pages:
        raise KnowledgeError("DOCUMENT_LIMIT", "PDF 页数超过解析限制")
    page_texts = [(page.extract_text() or "").strip() for page in reader.pages]
    page_count = len(page_texts)
    if policy.detect_scanned_pdf and page_count:
        scanned = tuple(
            number
            for number, text in enumerate(page_texts, start=1)
            if len(text) < policy.pdf_scan_min_chars_per_page
        )
        needed = max(1, math.ceil(page_count * policy.pdf_scan_page_ratio))
        # 短文档里的一页封面不该把整份送进 OCR，所以两页以上才按比例判定。
        if len(scanned) >= needed and (page_count == 1 or len(scanned) >= 2):
            # Text pages and OCR pages would otherwise merge inconsistently, so the
            # host re-reads the whole document once instead of stitching two sources.
            raise PdfNeedsOcr(scanned, page_count)
    found_text = False
    for number, text in enumerate(page_texts, start=1):
        if text:
            found_text = True
            yield Block(text, page=number)
    if not found_text:
        raise KnowledgeError("PDF_NO_TEXT", "PDF 中未提取到文字")


def parse_document_bytes(filename: str, raw: bytes, *, policy: DocumentPolicy = DocumentPolicy()) -> Parsed:
    """Parse trusted-sized bytes; callers choose process isolation for untrusted uploads."""
    suffix = PurePath(filename).suffix.lower()
    if suffix == ".pdf":
        version, source = "pypdf-v1", _pdf_blocks(raw, policy)
    elif suffix == ".docx":
        version, source = "docx-xml-v1", _docx_blocks(raw, policy)
    elif suffix in {".txt", ".md", ".markdown"} | policy.extra_text_formats:
        try:
            text = raw.decode("utf-8" if policy.strict_utf8 else "utf-8-sig")
        except UnicodeDecodeError:
            if policy.strict_utf8:
                raise KnowledgeError("INVALID_DOCUMENT", "文档编码无效") from None
            text = raw.decode("gb18030")
        if len(text) > policy.max_content_chars:
            if not policy.truncate_content:
                raise KnowledgeError(
                    "CONTENT_TOO_LONG",
                    f"正文 {format_char_count(len(text))}，超过单份 "
                    f"{format_char_count(policy.max_content_chars)}上限，请拆分后再上传",
                )
            text = text[:policy.max_content_chars]
        if suffix == ".json":
            try:
                json.loads(text)
            except json.JSONDecodeError as exc:
                raise KnowledgeError("INVALID_DOCUMENT", "JSON 文档无效") from exc
        elif suffix in {".html", ".htm"}:
            extractor = _HtmlText()
            extractor.feed(text)
            extractor.close()
            text = "".join(extractor.parts)
        version = "markdown-v1" if suffix in {".md", ".markdown"} else "text-v1"
        source = (
            Block(line, paragraph=index)
            for index, line in enumerate(text.splitlines(), start=1)
            if line.strip()
        )
    else:
        raise KnowledgeError("UNSUPPORTED_FORMAT", "不支持此文档格式")

    blocks = []
    length = 0
    for block in source:
        remaining = policy.max_content_chars - length - (2 if blocks else 0)
        if len(block.text) > remaining:
            if not policy.truncate_content:
                # 分块累计时只能确认「已超过」，报下限比报一个猜出来的总数更诚实。
                observed = length + (2 if blocks else 0) + len(block.text)
                raise KnowledgeError(
                    "CONTENT_TOO_LONG",
                    f"正文至少 {format_char_count(observed)}，超过单份 "
                    f"{format_char_count(policy.max_content_chars)}上限，请拆分后再上传",
                )
            if remaining > 0:
                blocks.append(replace(block, text=block.text[:remaining]))
            break
        length += len(block.text) + (2 if blocks else 0)
        blocks.append(block)
    return Parsed(version, tuple(blocks))


def render_document_text(filename: str, parsed: Parsed) -> str:
    suffix = PurePath(filename).suffix.lower()
    if suffix in {".txt", ".md", ".markdown", ".csv", ".json", ".html", ".htm"}:
        parts: list[str] = []
        previous = 0
        for block in parsed.blocks:
            line = block.paragraph or previous + 1
            if previous:
                parts.append("\n" * max(1, line - previous))
            parts.append(block.text)
            previous = line
        return "".join(parts)
    return ("\n\n" if suffix == ".pdf" else "\n").join(block.text for block in parsed.blocks)


def _child(sender, filename: str, content: bytes, policy: DocumentPolicy) -> None:
    with sender:
        try:
            result = parse_document_bytes(filename, content, policy=policy)
        except PdfNeedsOcr as exc:
            sender.send((None, exc.code, str(exc), {"pages": exc.pages, "pageCount": exc.page_count}))
        except KnowledgeError as exc:
            sender.send((None, exc.code, str(exc), None))
        except Exception:
            sender.send((None, "INVALID_DOCUMENT", "文档无法读取，请检查文件是否损坏", None))
        else:
            sender.send((result, None, None, None))


async def parse_document(
    filename: str, content: bytes, *, timeout: float = 30, policy: DocumentPolicy = DocumentPolicy()
) -> Parsed:
    context = multiprocessing.get_context("spawn")
    receiver, sender = context.Pipe(duplex=False)
    process = context.Process(target=_child, args=(sender, filename, content, policy))
    try:
        process.start()
        sender.close()
        async with asyncio.timeout(timeout):
            while not receiver.poll():
                if not process.is_alive() and not receiver.poll():
                    raise KnowledgeError(
                        "DOCUMENT_WORKER_EXIT", "文档解析中断", retryable=True
                    )
                await asyncio.sleep(0.02)
            try:
                result, code, message, detail = receiver.recv()
            except EOFError as exc:
                raise KnowledgeError(
                    "DOCUMENT_WORKER_EXIT", "文档解析中断", retryable=True
                ) from exc
        if result is None:
            if code == "PDF_NEEDS_OCR" and detail:
                raise PdfNeedsOcr(detail["pages"], detail["pageCount"])
            raise KnowledgeError(code, message)
        return result
    except TimeoutError as exc:
        raise KnowledgeError("PARSE_TIMEOUT", "文档解析超时", retryable=True) from exc
    finally:
        receiver.close()
        sender.close()
        if process.pid is not None:
            if process.is_alive():
                process.terminate()
            await asyncio.to_thread(process.join, 2)
            if process.is_alive():
                process.kill()
                await asyncio.to_thread(process.join)
        process.close()


def material_document_policy() -> DocumentPolicy:
    return DocumentPolicy(max_content_chars=INTAKE.document_max_chars, strict_docx_package=True)


async def parse_document_content(filename: str, raw: bytes, *, timeout: float = 60):
    """Bounded document parsing and normalized content, shared by all material workers."""
    from .content import build_content

    return build_content(await parse_document(
        filename, raw, timeout=timeout,
        policy=material_document_policy(),
    ))
