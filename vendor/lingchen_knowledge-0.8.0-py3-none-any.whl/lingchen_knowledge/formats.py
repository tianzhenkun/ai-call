import re
import unicodedata
from dataclasses import dataclass
from pathlib import PurePath

from .limits import CREATION, INTAKE, carrier_max_bytes, limits_payload
from .intake import MATERIAL_LINK_POLICY
from .models import KnowledgeError, MediaType

MIB = 1024 * 1024
CATEGORIES = {
    "product_service": "产品与服务",
    "faq": "FAQ",
    "case_study": "案例与专业沉淀",
    "industry": "行业知识",
    "other": "其他",
}


@dataclass(frozen=True, slots=True)
class Format:
    media_type: MediaType
    mime_type: str
    max_bytes: int


_GROUPS: dict[MediaType, dict[str, str]] = {
    "document": {
        ".txt": "text/plain",
        ".md": "text/markdown",
        ".markdown": "text/markdown",
        ".csv": "text/csv",
        ".json": "application/json",
        ".html": "text/html",
        ".htm": "text/html",
        ".pdf": "application/pdf",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    },
    "image": {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".webp": "image/webp",
    },
    "audio": {
        ".mp3": "audio/mpeg",
        ".wav": "audio/wav",
        ".m4a": "audio/mp4",
        ".aac": "audio/aac",
        ".flac": "audio/flac",
        ".ogg": "audio/ogg",
        ".opus": "audio/opus",
    },
    "video": {
        ".mp4": "video/mp4",
        ".mov": "video/quicktime",
        ".mkv": "video/x-matroska",
        ".webm": "video/webm",
        ".avi": "video/x-msvideo",
        ".mpeg": "video/mpeg",
        ".mpg": "video/mpeg",
    },
}
_FORMATS = {
    suffix: Format(media_type, mime, carrier_max_bytes(media_type))
    for media_type, formats in _GROUPS.items()
    for suffix, mime in formats.items()
}


def policy() -> dict:
    return {
        "version": "3",
        "links": {
            "protocols": sorted(f"{scheme}:" for scheme in MATERIAL_LINK_POLICY.schemes),
            "forbidCustomPort": not MATERIAL_LINK_POLICY.allow_explicit_port,
            "maxLength": 2048,
            "maxLinks": CREATION.max_link_items,
        },
        "maxBatchBytes": INTAKE.batch_max_bytes,
        "formats": [
            {
                "suffix": suffix,
                "carrierType": fmt.media_type,
                "mimeType": fmt.mime_type,
                "maxBytes": fmt.max_bytes,
            }
            for suffix, fmt in _FORMATS.items()
        ],
        "categories": [
            {"value": code, "label": label} for code, label in CATEGORIES.items()
        ],
        "limits": limits_payload(),
    }


def classify(filename: str) -> Format:
    if (
        not filename.strip()
        or filename != filename.strip()
        or len(filename) > 255
        or "/" in filename
        or "\\" in filename
        or any(ord(c) < 32 for c in filename)
    ):
        raise KnowledgeError("INVALID_FILENAME", "文件名无效")
    fmt = _FORMATS.get(PurePath(filename).suffix.lower())
    if fmt is None:
        raise KnowledgeError("UNSUPPORTED_FORMAT", "不支持此文件格式")
    return fmt


def validate_filename(
    filename: str, *, strip: bool = False, basename: bool = False,
    max_bytes: int | None = None, max_length: int = 255,
) -> str:
    value = unicodedata.normalize("NFC", filename.strip() if strip else filename)
    if basename:
        value = value.replace("\\", "/").rsplit("/", 1)[-1].strip()
    if (not value or value in {".", ".."} or len(value) > max_length
            or (max_bytes is not None and len(value.encode("utf-8")) > max_bytes)
            or re.search(r"[/\\\x00-\x1f\x7f]", value)):
        raise KnowledgeError("INVALID_FILENAME", "文件名无效")
    return value


def validate_declared_mime(
    expected: str, declared: str | None, *, aliases: frozenset[str] | set[str] = frozenset(),
) -> bool:
    candidate = (declared or "").split(";", 1)[0].strip().lower()
    if candidate not in {"", "application/octet-stream", expected, *aliases}:
        raise KnowledgeError("FORMAT_MISMATCH", "文件类型与扩展名不匹配")
    return True


def validate_size(size: int, *, maximum: int) -> None:
    if size < 1:
        raise KnowledgeError("EMPTY_FILE", "不能上传空文件")
    if size > maximum:
        raise KnowledgeError("FILE_TOO_LARGE", "文件超过大小限制")


def validate_count(count: int, *, maximum: int) -> None:
    if count > maximum:
        raise KnowledgeError("COUNT_LIMIT", "文件数量超过限制")


def matches_signature(
    suffix: str,
    head: bytes,
    *,
    text_suffixes: frozenset[str] | set[str] = frozenset(),
    pdf_at_start: bool = False,
) -> bool:
    if suffix in {".txt", ".md", ".markdown", ".csv", ".json", ".html", ".htm"} | set(text_suffixes):
        return b"\x00" not in head
    if suffix == ".pdf":
        return head.startswith(b"%PDF-") if pdf_at_start else b"%PDF-" in head[:1024]
    if suffix == ".docx":
        return head.startswith(b"PK\x03\x04")
    if suffix in {".jpg", ".jpeg"}:
        return head.startswith(b"\xff\xd8\xff")
    if suffix == ".png":
        return head.startswith(b"\x89PNG\r\n\x1a\n")
    if suffix == ".webp":
        return head[:4] == b"RIFF" and head[8:12] == b"WEBP"
    if suffix in {".wav", ".avi"}:
        return head[:4] in {b"RIFF", b"RF64", b"RIFX"} and head[8:12] == (
            b"WAVE" if suffix == ".wav" else b"AVI "
        )
    if suffix in {".mp4", ".mov", ".m4a"}:
        return head[4:8] == b"ftyp" or (
            suffix == ".mov" and head[4:8] in {b"wide", b"moov", b"mdat", b"free"}
        )
    if suffix in {".mkv", ".webm"}:
        return (
            head.startswith(b"\x1a\x45\xdf\xa3")
            and (b"webm" if suffix == ".webm" else b"matroska") in head
        )
    if suffix in {".ogg", ".opus"}:
        return head.startswith(b"OggS") and (suffix != ".opus" or b"OpusHead" in head)
    if suffix == ".flac":
        return head.startswith(b"fLaC")
    if suffix == ".mp3":
        return head.startswith(b"ID3") or (
            len(head) >= 4 and head[0] == 0xFF and head[1] & 0xE6 in {0xE2, 0xE4, 0xE6}
        )
    if suffix == ".aac":
        return head.startswith(b"ADIF") or (
            len(head) >= 7 and head[0] == 0xFF and head[1] & 0xF6 == 0xF0
        )
    return head.startswith((b"\x00\x00\x01\xba", b"\x00\x00\x01\xb3"))


def _matches(suffix: str, head: bytes) -> bool:
    return matches_signature(suffix, head)


def validate_file(
    filename: str, content: bytes, declared_mime: str | None = None
) -> Format:
    fmt = classify(filename)
    if not content:
        raise KnowledgeError("EMPTY_FILE", "不能上传空文件")
    if len(content) > fmt.max_bytes:
        raise KnowledgeError(
            "FILE_TOO_LARGE", f"单个文件不能超过 {fmt.max_bytes // MIB} MB"
        )
    mime = (declared_mime or "").partition(";")[0].lower().strip()
    expected_prefix = fmt.mime_type.partition("/")[0]
    # Browsers and object stores may omit MIME or supply a generic binary type.
    if (
        mime.split("/")[0] in {"image", "audio", "video", "text"}
        and mime.split("/")[0] != expected_prefix
        and not (
            fmt.media_type in {"audio", "video"}
            and mime.startswith(("audio/", "video/"))
        )
    ):
        raise KnowledgeError("FORMAT_MISMATCH", "文件类型与扩展名不匹配")
    if not _matches(PurePath(filename).suffix.lower(), content[:4096]):
        raise KnowledgeError("FORMAT_MISMATCH", "文件内容与扩展名不匹配")
    return fmt
