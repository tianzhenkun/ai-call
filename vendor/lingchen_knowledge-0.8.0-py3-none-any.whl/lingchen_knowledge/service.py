import json
from collections.abc import Sequence
from datetime import datetime

from .content import digest
from .formats import CATEGORIES, classify, validate_file
from .intake import ready_material
from .models import (
    Access,
    Item,
    KnowledgeError,
    MediaType,
    Original,
    Originals,
    Page,
    Repository,
    Scope,
    Selection,
    UploadRecord,
)

MAX_SELECTION = 50
MAX_SELECTION_PAGE = 10


class KnowledgeService:
    def __init__(self, repository: Repository, originals: Originals | None):
        self.repository = repository
        self.originals = originals

    async def upload(
        self,
        access: Access,
        *,
        scope: Scope,
        key: str,
        filename: str,
        content: bytes,
        category: str,
        note: str | None = None,
        mime_type: str | None = None,
    ) -> Item:
        if (
            not key
            or len(key) > 128
            or key.strip() != key
            or any(ord(c) < 32 for c in key)
        ):
            raise KnowledgeError("INVALID_UPLOAD_KEY", "上传编号无效")
        if scope == "workspace_user":
            if not access.workspace_id or not access.workspace_id.strip():
                raise KnowledgeError("KNOWLEDGE_UNAVAILABLE", "当前工作区不可用")
        elif scope == "tenant":
            if not (access.read_shared and access.manage_shared):
                raise KnowledgeError("KNOWLEDGE_UNAVAILABLE", "无权上传共享资料")
        elif scope != "user":
            raise KnowledgeError("KNOWLEDGE_UNAVAILABLE", "资料范围无效")
        if category not in CATEGORIES:
            raise KnowledgeError("INVALID_CATEGORY", "请选择有效的分类")
        if note is not None and len(note) > 2000:
            raise KnowledgeError("INVALID_NOTE", "备注最多 2000 字")
        fmt = validate_file(filename, content, mime_type)
        sha = digest(content)
        workspace = access.workspace_id if scope == "workspace_user" else None
        fingerprint = digest(
            json.dumps([scope, workspace, filename, category, note, sha]).encode()
        )
        item_id = digest(json.dumps([access.tenant_id, access.user_id, key]).encode())[
            :32
        ]
        proposed = Original(
            f"{item_id}-{fingerprint}", filename, fmt.mime_type, len(content), sha
        )
        record = UploadRecord(
            item_id,
            key,
            fingerprint,
            scope,
            workspace,
            filename,
            fmt.media_type,
            category,
            note,
            proposed,
        )

        async def persist() -> str:
            if self.originals is None:
                raise KnowledgeError("ORIGINAL_STORE_UNAVAILABLE", "原件存储未配置")
            try:
                return await self.originals.put(access.tenant_id, proposed, content)
            except OSError as exc:
                raise KnowledgeError(
                    "ORIGINAL_STORE_UNAVAILABLE",
                    "暂时无法保存原件，请重试",
                    retryable=True,
                ) from exc

        return await self.repository.accept_upload(access, record, persist)

    async def list(
        self,
        access: Access,
        *,
        media_type: MediaType | None = None,
        category: str | None = None,
        search: str = "",
        page: int = 1,
        page_size: int = 20,
    ) -> Page:
        if (
            not 1 <= page <= 10_000
            or not 1 <= page_size <= 100
            or len(search) > 200
            or (category is not None and category not in CATEGORIES)
            or (
                media_type is not None
                and media_type not in {"document", "image", "audio", "video"}
            )
        ):
            raise KnowledgeError("INVALID_QUERY", "筛选或分页参数无效")
        return await self.repository.list_items(
            access,
            media_type=media_type,
            category=category,
            search=search.strip(),
            limit=page_size,
            offset=(page - 1) * page_size,
        )

    async def detail(self, access: Access, item_id: str) -> Item:
        item = await self.repository.get_item(access, item_id)
        if not access.allows(item):
            raise KnowledgeError("KNOWLEDGE_UNAVAILABLE", "资料不存在或当前无法读取")
        return item

    async def original(self, access: Access, item_id: str) -> Original:
        """Return metadata only after authorization so the host can stream the original."""
        return (await self.detail(access, item_id)).original

    async def update(
        self,
        access: Access,
        item_id: str,
        fields: dict[str, str | None],
        *,
        expected_updated_at: datetime | None = None,
    ) -> Item:
        if not fields or fields.keys() - {"name", "category", "note"}:
            raise KnowledgeError("INVALID_UPDATE", "请选择需要修改的资料字段")
        fields = fields.copy()
        if "name" in fields:
            name = (fields["name"] or "").strip()
            if not name or len(name) > 255 or any(ord(c) < 32 for c in name):
                raise KnowledgeError("INVALID_NAME", "资料名称无效")
            fields["name"] = name
        if "category" in fields and fields["category"] not in CATEGORIES:
            raise KnowledgeError("INVALID_CATEGORY", "请选择有效的分类")
        if len(fields.get("note") or "") > 2000:
            raise KnowledgeError("INVALID_NOTE", "备注最多 2000 字")
        return await self.repository.update_item(
            access, item_id, fields, expected_updated_at=expected_updated_at
        )

    async def select(
        self,
        access: Access,
        item_ids: Sequence[str],
        *,
        offset: int = 0,
        limit: int = MAX_SELECTION_PAGE,
    ) -> tuple[tuple[Selection, ...], int | None]:
        if isinstance(item_ids, str) or not 1 <= len(item_ids) <= MAX_SELECTION:
            raise KnowledgeError("INVALID_SELECTION", "请选择 1 至 50 份资料")
        ids = tuple(dict.fromkeys(item_ids))
        if (
            any(not item.strip() or len(item) > 64 for item in ids)
            or not 0 <= offset < len(ids)
            or not 1 <= limit <= MAX_SELECTION_PAGE
        ):
            raise KnowledgeError("INVALID_SELECTION", "资料选择或分页参数无效")
        window = ids[offset : offset + limit]
        result = await self.repository.read_ready(access, window)
        if tuple(row.item.id for row in result) != window or any(
            not access.allows(row.item) or row.item.status != "ready" for row in result
        ):
            raise KnowledgeError(
                "KNOWLEDGE_UNAVAILABLE", "所选资料无法读取或尚未解析完成"
            )
        for row in result:
            ready_material(
                source_id=row.item.id, name=row.item.name, status=row.item.status,
                text=row.content.text, parser_version=row.content.parser_version,
            )
        next_offset = offset + len(window)
        return result, next_offset if next_offset < len(ids) else None

    async def retry(self, access: Access, item_id: str) -> Item:
        return await self.repository.retry(access, item_id)

    async def delete(self, access: Access, item_id: str) -> None:
        await self.repository.delete(access, item_id)


def max_file_bytes(filename: str) -> int:
    """Host endpoints use this before reading a multipart payload."""
    return classify(filename).max_bytes
