from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Literal, Protocol

MediaType = Literal["document", "image", "audio", "video"]
Scope = Literal["user", "workspace_user", "tenant"]
Status = Literal["pending", "processing", "ready", "failed"]
ProviderState = Literal["unknown", "submitted", "resolved"]


class KnowledgeError(ValueError):
    def __init__(self, code: str, message: str, *, retryable: bool = False):
        super().__init__(message)
        self.code = code
        self.retryable = retryable


@dataclass(frozen=True, slots=True)
class Access:
    """Construct from the host's authenticated and authorized identity."""

    tenant_id: str
    user_id: str
    workspace_id: str | None = None
    read_shared: bool = False
    manage_shared: bool = False

    def __post_init__(self):
        if not self.tenant_id.strip() or not self.user_id.strip():
            raise KnowledgeError("KNOWLEDGE_UNAVAILABLE", "缺少有效的访问身份")

    def allows(self, item: "Item", *, manage: bool = False) -> bool:
        if item.tenant_id != self.tenant_id:
            return False
        if item.scope == "tenant":
            return self.read_shared and (not manage or self.manage_shared)
        if item.owner_user_id != self.user_id:
            return False
        return item.scope == "user" or (
            item.scope == "workspace_user"
            and self.workspace_id is not None
            and item.workspace_id == self.workspace_id
        )


@dataclass(frozen=True, slots=True)
class Original:
    ref: str
    filename: str
    mime_type: str
    size_bytes: int
    sha256: str


@dataclass(frozen=True, slots=True)
class Item:
    id: str
    tenant_id: str
    scope: Scope
    owner_user_id: str | None
    workspace_id: str | None
    name: str
    media_type: MediaType
    category: str
    note: str | None
    original: Original
    status: Status
    created_at: datetime
    updated_at: datetime
    error_code: str | None = None
    error_message: str | None = None
    retryable: bool = False
    poll: bool = False


@dataclass(frozen=True, slots=True)
class Block:
    text: str
    page: int | None = None
    paragraph: int | None = None
    start_ms: int | None = None
    end_ms: int | None = None
    speaker: str | None = None


@dataclass(frozen=True, slots=True)
class Parsed:
    parser_version: str
    blocks: tuple[Block, ...]
    page_count: int | None = None
    duration_seconds: float | None = None


@dataclass(frozen=True, slots=True)
class Chunk:
    ordinal: int
    text: str
    sha256: str
    locator: dict[str, int | str]


@dataclass(frozen=True, slots=True)
class Content:
    text: str
    sha256: str
    parser_version: str
    chunker_version: str
    chunks: tuple[Chunk, ...]


@dataclass(frozen=True, slots=True)
class Selection:
    item: Item
    content: Content


@dataclass(frozen=True, slots=True)
class Page:
    items: tuple[Item, ...]
    total: int


@dataclass(frozen=True, slots=True)
class Claim:
    item: Item
    run_no: int
    token: str
    attempt: int
    provider_name: str | None = None
    provider_state: ProviderState | None = None
    request_key: str | None = None
    job_id: str | None = None
    provider_started_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class UploadRecord:
    item_id: str
    key: str
    fingerprint: str
    scope: Scope
    workspace_id: str | None
    name: str
    media_type: MediaType
    category: str
    note: str | None
    original: Original


class Originals(Protocol):
    async def put(self, tenant_id: str, original: Original, content: bytes) -> str:
        """Persist idempotently at the proposed reference and return the stable host reference."""
        ...

    async def read(self, tenant_id: str, original: Original) -> bytes: ...


class Repository(Protocol):
    """Hosts provide atomic writes and apply Access in the query, before pagination."""

    async def accept_upload(
        self,
        access: Access,
        record: UploadRecord,
        persist: Callable[[], Awaitable[str]],
    ) -> Item: ...

    async def list_items(
        self,
        access: Access,
        *,
        media_type: MediaType | None,
        category: str | None,
        search: str,
        limit: int,
        offset: int,
    ) -> Page: ...

    async def get_item(self, access: Access, item_id: str) -> Item: ...

    async def update_item(
        self,
        access: Access,
        item_id: str,
        fields: dict[str, str | None],
        *,
        expected_updated_at: datetime | None,
    ) -> Item: ...

    async def read_ready(
        self, access: Access, ids: Sequence[str]
    ) -> tuple[Selection, ...]: ...

    async def retry(self, access: Access, item_id: str) -> Item: ...

    async def delete(self, access: Access, item_id: str) -> None:
        """Check host references under the same lock used to establish a reference."""
        ...

    async def claim(self, *, lease_seconds: float) -> Claim | None: ...

    async def remember_provider(
        self, claim: Claim, *, name: str, request_key: str, job_id: str | None
    ) -> bool: ...

    async def complete(self, claim: Claim, content: Content) -> bool: ...

    async def release(
        self,
        claim: Claim,
        *,
        status: Status,
        delay: float | None,
        error: KnowledgeError | None = None,
        clear_provider: bool = False,
        reset_attempts: bool = False,
    ) -> bool: ...


class MediaProvider(Protocol):
    name: str

    async def prepare(
        self, claim: Claim, content: bytes, request_key: str
    ) -> bytes | str: ...

    async def submit(self, source: bytes | str, request_key: str) -> str: ...

    async def recover(self, request_key: str) -> str | None:
        """Return a known job ID or None. Missing never authorizes another submit."""
        ...

    async def poll(self, job_id: str) -> Parsed | None: ...
