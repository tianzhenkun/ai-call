from hashlib import sha256

from .limits import INTAKE
from .models import Chunk, Content, KnowledgeError, Parsed

MAX_CONTENT_CHARS = INTAKE.document_max_chars
CHUNK_CHARS = 1000
CHUNKER_VERSION = "source-window-v1"


def digest(data: bytes) -> str:
    return sha256(data).hexdigest()


def build_content(parsed: Parsed) -> Content:
    text_blocks: list[str] = []
    chunks: list[Chunk] = []
    total = 0
    for block in parsed.blocks:
        text = "\n".join(
            line.rstrip()
            for line in block.text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        ).strip()
        if not text:
            continue
        if "\x00" in text:
            raise KnowledgeError("INVALID_TEXT", "正文含无效字符")
        total += len(text) + (2 if text_blocks else 0)
        if total > MAX_CONTENT_CHARS:
            raise KnowledgeError(
                "CONTENT_TOO_LONG",
                f"正文 {format_char_count(total)}，超过单份 "
                f"{format_char_count(MAX_CONTENT_CHARS)}上限，请拆分后再上传",
            )
        text_blocks.append(text)
        locator = {
            name: value
            for name, value in (
                ("page", block.page),
                ("paragraph", block.paragraph),
                ("startMs", block.start_ms),
                ("endMs", block.end_ms),
                ("speaker", block.speaker),
            )
            if value is not None
        }
        start = 0
        while start < len(text):
            end = min(len(text), start + CHUNK_CHARS)
            if end < len(text):
                for separator in ("\n", "。", "！", "？", ". ", " "):
                    split = text.rfind(separator, start + CHUNK_CHARS // 2, end)
                    if split != -1:
                        end = split + len(separator)
                        break
            part = text[start:end].strip()
            if part:
                chunks.append(
                    Chunk(
                        len(chunks) + 1,
                        part,
                        digest(part.encode()),
                        {**locator, "offset": start},
                    )
                )
            start = end
    if not chunks:
        raise KnowledgeError("NO_EXTRACTABLE_TEXT", "未提取到可用正文")
    body = "\n\n".join(text_blocks)
    return Content(
        body,
        digest(body.encode()),
        parsed.parser_version,
        CHUNKER_VERSION,
        tuple(chunks),
    )


def content_chars(text: str | None) -> int:
    """可见字符数，空白不计。

    用户判断"这份资料够不够用"看的是字数，不是字节：同样 20 MB 可能是 300 万字
    文字版，也可能是 0 字扫描件。前后端都用这一个口径，避免列表显示和预算计算
    算出两个数。
    """
    return sum(1 for char in (text or "") if not char.isspace())


def format_char_count(chars: int) -> str:
    """字数文案：报错信息和界面显示用同一套写法，避免「200000 字」和「20 万字」并存。

    除不尽的一律保留一位小数，整数不带 ``.0``：200_000 → "20 万字"，
    32_000 → "3.2 万字"，860 → "860 字"。前端 ``formatChars`` 与这里保持一致。
    """
    total = max(0, int(chars))
    if total < 10_000:
        return f"{total} 字"
    wan = total / 10_000
    return f"{wan:.0f} 万字" if wan >= 100 else f"{wan:.1f}".rstrip("0").rstrip(".") + " 万字"
