"""Bounded public link reads. DNS answers are checked before each pinned connection."""

from __future__ import annotations

import asyncio
import http.client
import ipaddress
import re
import socket
import ssl
import zlib
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from html.parser import HTMLParser
from urllib.parse import SplitResult, urljoin, urlsplit


_REDIRECTS = {301, 302, 303, 307, 308}
_BLOCKED = tuple(ipaddress.ip_network(value) for value in (
    "0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8",
    "169.254.0.0/16", "172.16.0.0/12", "192.0.0.0/24", "192.0.2.0/24",
    "192.88.99.0/24", "192.168.0.0/16", "198.18.0.0/15", "198.51.100.0/24",
    "203.0.113.0/24", "224.0.0.0/4", "240.0.0.0/4", "::/96",
    "64:ff9b:1::/48", "64:ff9b::/96", "100::/64", "2001::/23",
    "2001:db8::/32", "2002::/16", "fc00::/7", "fe80::/10",
    "fec0::/10", "ff00::/8",
))


class LinkReadError(ValueError):
    def __init__(self, code: str, *, detail: str | None = None):
        super().__init__(code)
        self.code = code
        self.detail = detail


class LinkResponseTooLargeError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class LinkPolicy:
    schemes: frozenset[str] = frozenset({"https"})
    allowed_mime: frozenset[str] | None = frozenset({"text/html", "application/xhtml+xml"})
    allow_any_text: bool = False
    allow_explicit_port: bool = False
    allow_ip_literal: bool = False
    require_global_ip: bool = False
    max_redirects: int = 3
    max_bytes: int = 2 * 1024 * 1024
    timeout_seconds: float = 10.0
    request_timeout_seconds: float | None = None
    connect_timeout_seconds: float | None = None
    dns_timeout_seconds: float | None = None
    allow_compression: bool = False
    user_agent: str = "LingChen-Knowledge/1.0"


@dataclass(frozen=True, slots=True)
class LinkRequest:
    url: str
    address: str
    family: int
    timeout_seconds: float
    max_bytes: int
    port: int = 443
    user_agent: str = "LingChen-Knowledge/1.0"
    connect_timeout_seconds: float | None = None
    allow_compression: bool = False


@dataclass(frozen=True, slots=True)
class LinkResponse:
    status: int
    headers: dict[str, str]
    body: bytes


@dataclass(frozen=True, slots=True)
class LinkResult:
    final_url: str
    mime_type: str
    text: str
    body: bytes


DnsLookup = Callable[[str, int], Awaitable[list[tuple[str, int]]]]
Transport = Callable[[LinkRequest], Awaitable[LinkResponse]]


def validate_public_url(value: str, policy: LinkPolicy) -> SplitResult:
    if not value or value != value.strip():
        raise LinkReadError("invalid_url")
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError as exc:
        raise LinkReadError("invalid_url") from exc
    if parsed.scheme.lower() not in policy.schemes:
        raise LinkReadError("unsupported_url")
    hostname = parsed.hostname or ""
    if not hostname:
        raise LinkReadError("invalid_url")
    if (parsed.username is not None or parsed.password is not None
            or (port is not None and not policy.allow_explicit_port)
            or hostname.endswith(".")):
        raise LinkReadError("unsafe_url")
    if not policy.allow_ip_literal:
        try:
            ipaddress.ip_address(hostname.strip("[]"))
        except ValueError:
            pass
        else:
            raise LinkReadError("unsafe_url")
    return parsed


def validate_public_address(value: str, family: int, *, require_global: bool = False) -> None:
    try:
        address = ipaddress.ip_address(value.split("%", 1)[0])
    except ValueError as exc:
        raise LinkReadError("unsafe_address") from exc
    if (address.version != family or getattr(address, "ipv4_mapped", None) is not None
            or any(address in network for network in _BLOCKED)
            or (require_global and not address.is_global)):
        raise LinkReadError("unsafe_address")


async def _default_dns(hostname: str, port: int) -> list[tuple[str, int]]:
    def lookup() -> list[tuple[str, int]]:
        results = socket.getaddrinfo(hostname, port, type=socket.SOCK_STREAM)
        unique = []
        for family, _type, _protocol, _canonical, address in results:
            if family in {socket.AF_INET, socket.AF_INET6}:
                candidate = (address[0], 4 if family == socket.AF_INET else 6)
                if candidate not in unique:
                    unique.append(candidate)
        return unique
    return await asyncio.to_thread(lookup)


class _PinnedConnection(http.client.HTTPConnection):
    def __init__(self, hostname: str, address: str, port: int, timeout: float, https: bool,
                 connect_timeout: float | None):
        # 标准库生成 Host 时须省略当前协议的默认端口，否则签名下载会失败。
        self.default_port = http.client.HTTPS_PORT if https else http.client.HTTP_PORT
        super().__init__(hostname, port=port, timeout=timeout)
        self.address = address
        self.https = https
        self.connect_timeout = connect_timeout or timeout

    def connect(self) -> None:
        raw = socket.create_connection((self.address, self.port), self.connect_timeout, self.source_address)
        if self.https:
            self.sock = ssl.create_default_context().wrap_socket(raw, server_hostname=self.host)
        else:
            self.sock = raw
        self.sock.settimeout(self.timeout)


def _request_pinned(request: LinkRequest) -> LinkResponse:
    parsed = urlsplit(request.url)
    connection = _PinnedConnection(
        parsed.hostname or "", request.address, request.port,
        request.timeout_seconds, parsed.scheme == "https", request.connect_timeout_seconds,
    )
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query
    try:
        connection.request("GET", path, headers={
            "Accept": "text/html,application/xhtml+xml,text/plain,text/markdown,application/json",
            "Accept-Encoding": "gzip, deflate, br" if request.allow_compression else "identity",
            "User-Agent": request.user_agent,
        })
        response = connection.getresponse()
        headers: dict[str, str] = {}
        for name, value in response.getheaders():
            normalized = name.lower()
            headers[normalized] = f"{headers[normalized]}, {value}" if normalized in headers else value
        if response.status in _REDIRECTS:
            return LinkResponse(response.status, headers, b"")
        declared = headers.get("content-length", "")
        if declared.isdigit() and int(declared) > request.max_bytes:
            raise LinkResponseTooLargeError
        chunks, size = [], 0
        while chunk := response.read(min(65536, request.max_bytes + 1 - size)):
            size += len(chunk)
            if size > request.max_bytes:
                raise LinkResponseTooLargeError
            chunks.append(chunk)
        return LinkResponse(response.status, headers, b"".join(chunks))
    finally:
        connection.close()


async def _default_transport(request: LinkRequest) -> LinkResponse:
    return await asyncio.to_thread(_request_pinned, request)


def _decode(body: bytes, content_type: str) -> str:
    match = re.search(r"charset\s*=\s*[\"']?([^;\"'\s]+)", content_type, re.I)
    try:
        return body.decode(match.group(1) if match else "utf-8", errors="replace")
    except LookupError:
        return body.decode("utf-8", errors="replace")


def _decompress(body: bytes, encoding: str, maximum: int) -> bytes:
    if not encoding or encoding == "identity":
        return body
    if encoding in {"gzip", "deflate"}:
        try:
            decoder = zlib.decompressobj(16 + zlib.MAX_WBITS if encoding == "gzip" else zlib.MAX_WBITS)
            result = bytearray()
            for start in range(0, len(body), 65536):
                part = decoder.decompress(body[start:start + 65536], maximum + 1 - len(result))
                result.extend(part)
                if len(result) > maximum or decoder.unconsumed_tail:
                    raise LinkReadError("response_too_large")
            result.extend(decoder.flush(maximum + 1 - len(result)))
            if len(result) > maximum or not decoder.eof:
                raise LinkReadError("response_too_large")
            return bytes(result)
        except zlib.error as exc:
            raise LinkReadError("fetch_failed") from exc
    if encoding == "br":
        try:
            import brotli
        except ImportError as exc:
            raise LinkReadError("unsupported_content_encoding") from exc
        decoder = brotli.Decompressor()
        result = bytearray()
        try:
            for start in range(0, len(body), 1024):
                result.extend(decoder.process(body[start:start + 1024]))
                if len(result) > maximum:
                    raise LinkReadError("response_too_large")
        except brotli.error as exc:
            raise LinkReadError("fetch_failed") from exc
        if not decoder.is_finished():
            raise LinkReadError("fetch_failed")
        return bytes(result)
    raise LinkReadError("unsupported_content_encoding")


async def read_public_link(
    url: str,
    policy: LinkPolicy,
    *,
    dns_lookup: DnsLookup | None = None,
    transport: Transport | None = None,
) -> LinkResult:
    dns = dns_lookup or _default_dns
    fetch = transport or _default_transport
    current = validate_public_url(url, policy)
    try:
        async with asyncio.timeout(policy.timeout_seconds):
            for redirects in range(policy.max_redirects + 1):
                port = current.port or (443 if current.scheme == "https" else 80)
                try:
                    addresses = await asyncio.wait_for(
                        dns(current.hostname or "", port),
                        timeout=policy.dns_timeout_seconds or policy.timeout_seconds,
                    )
                except LinkReadError:
                    raise
                except Exception as exc:
                    raise LinkReadError("dns_failed") from exc
                if not addresses:
                    raise LinkReadError("dns_failed")
                for address, family in addresses:
                    validate_public_address(address, family, require_global=policy.require_global_ip)
                try:
                    response = await asyncio.wait_for(fetch(LinkRequest(
                        current.geturl(), addresses[0][0], addresses[0][1],
                        policy.request_timeout_seconds or policy.timeout_seconds,
                        policy.max_bytes, port, policy.user_agent,
                        policy.connect_timeout_seconds, policy.allow_compression,
                    )), timeout=policy.request_timeout_seconds or policy.timeout_seconds)
                except LinkResponseTooLargeError as exc:
                    raise LinkReadError("response_too_large") from exc
                except LinkReadError:
                    raise
                except TimeoutError as exc:
                    raise LinkReadError("timed_out") from exc
                except Exception as exc:
                    raise LinkReadError("fetch_failed") from exc
                if response.status in _REDIRECTS:
                    if redirects >= policy.max_redirects:
                        raise LinkReadError("too_many_redirects")
                    location = response.headers.get("location", "")
                    if not location:
                        raise LinkReadError("missing_redirect_location")
                    current = validate_public_url(urljoin(current.geturl(), location), policy)
                    continue
                if not 200 <= response.status < 300:
                    raise LinkReadError(f"http_{response.status}")
                declared = response.headers.get("content-length", "")
                if (declared.isdigit() and int(declared) > policy.max_bytes
                        or len(response.body) > policy.max_bytes):
                    raise LinkReadError("response_too_large")
                mime = response.headers.get("content-type", "").split(";", 1)[0].strip().lower()
                if not mime and policy.allow_any_text:
                    mime = "text/html"
                if (policy.allowed_mime is not None and mime not in policy.allowed_mime
                        and not (policy.allow_any_text and mime.startswith("text/"))):
                    raise LinkReadError("unsupported_content_type", detail=mime)
                body = _decompress(
                    response.body, response.headers.get("content-encoding", "").strip().lower(),
                    policy.max_bytes,
                ) if policy.allow_compression else response.body
                return LinkResult(
                    current.geturl(), mime, _decode(body, response.headers.get("content-type", "")), body
                )
    except TimeoutError as exc:
        raise LinkReadError("total_timeout") from exc
    raise LinkReadError("too_many_redirects")


class _TextParser(HTMLParser):
    _SKIP = {"canvas", "noscript", "script", "style", "svg", "iframe", "object", "embed", "template"}
    _BLOCK = {"article", "aside", "blockquote", "br", "div", "footer", "h1", "h2", "h3", "h4", "header", "li", "main", "nav", "ol", "p", "section", "table", "td", "th", "tr", "ul"}

    def __init__(self, *, include_title_in_body: bool = False) -> None:
        super().__init__(convert_charrefs=True)
        self.depth = 0
        self.parts: list[str] = []
        self.title: list[str] = []
        self.in_title = False
        self.include_title_in_body = include_title_in_body

    def handle_starttag(self, tag, attrs):
        if tag in self._SKIP:
            self.depth += 1
        elif tag == "title":
            self.in_title = True
        elif tag in self._BLOCK:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in self._SKIP and self.depth:
            self.depth -= 1
        elif tag == "title":
            self.in_title = False
        elif tag in self._BLOCK:
            self.parts.append("\n")

    def handle_data(self, value):
        if self.in_title:
            self.title.append(value)
            if self.include_title_in_body:
                self.parts.append(value.strip())
        elif not self.depth:
            normalized = re.sub(r"\s+", " ", value).strip()
            if normalized:
                self.parts.append(normalized)


def extract_html_text(value: str, *, include_title_in_body: bool = False) -> tuple[str, str]:
    parser = _TextParser(include_title_in_body=include_title_in_body)
    parser.feed(value)
    parser.close()
    body = " ".join(parser.parts)
    body = re.sub(r"[ \t\f\v]+", " ", body)
    body = re.sub(r"\s*\n\s*", "\n", body)
    return "".join(parser.title).strip(), re.sub(r"\n{3,}", "\n\n", body).strip()
