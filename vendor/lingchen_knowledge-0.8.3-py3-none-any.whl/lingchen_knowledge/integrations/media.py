"""Explicit PaddleOCR and DashScope adapters. No network calls at import time."""

import asyncio
import io
import json
import math
import re
from collections.abc import Awaitable, Callable
from pathlib import Path, PurePath
from tempfile import TemporaryDirectory
from urllib.parse import quote, urlsplit

import httpx
from PIL import Image, ImageOps

from lingchen_knowledge.formats import MIB
from lingchen_knowledge.limits import INTAKE
from lingchen_knowledge.links import LinkPolicy, LinkReadError, read_public_link
from lingchen_knowledge.models import Block, Claim, KnowledgeError, Parsed
from lingchen_knowledge.processing import SubmissionUnknown

MAX_PROVIDER_RESULT_BYTES = 16 * MIB
MAX_IMAGE_PIXELS = 20_000_000
MAX_ASR_INPUT = INTAKE.asr_max_bytes
MAX_ASR_SECONDS = INTAKE.media_max_seconds
StageAudio = Callable[[Claim, str, bytes], Awaitable[str]]
_PADDLE_API = "https://paddleocr.aistudio-app.com"
# 保留宿主拼接自建服务域名的接口。官方任务无需配置额外的桶。
PADDLE_OCR_RESULT_HOSTS: tuple[str, ...] = ()
_BOS_ENDPOINTS = tuple(
    f"{region}.bcebos.com" for region in ("bj", "bd", "su", "gz", "cd", "yq", "hkg", "fwh", "fsh")
)
_BOS_DOWNLOAD = LinkPolicy(
    allowed_mime=None,
    allow_explicit_port=True,
    require_global_ip=True,
    max_redirects=0,
    max_bytes=MAX_PROVIDER_RESULT_BYTES,
    timeout_seconds=60,
    allow_compression=True,
)


def _https_url(value: str, hosts: tuple[str, ...] = ()) -> str:
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError as exc:
        raise KnowledgeError("PROVIDER_URL_INVALID", "解析文件地址无效") from exc
    host = (parsed.hostname or "").lower()
    if (
        parsed.scheme != "https"
        or not host
        or parsed.username is not None
        or parsed.password is not None
        or port not in {None, 443}
        or (
            hosts
            and not any(
                host == allowed or host.endswith("." + allowed) for allowed in hosts
            )
        )
    ):
        raise KnowledgeError("PROVIDER_URL_INVALID", "解析文件地址无效")
    return value


def _provider_error(message: str = "解析服务响应异常") -> KnowledgeError:
    return KnowledgeError("PROVIDER_RESPONSE", message, retryable=True)


def _is_pdf(content: bytes) -> bool:
    return content[:1024].find(b"%PDF-") != -1


def _object(value) -> dict:
    if not isinstance(value, dict):
        raise _provider_error()
    return value


def _array(value) -> list:
    return value if isinstance(value, list) else []


def _job_id(value) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", value):
        raise SubmissionUnknown()
    return value


def _result_hostnames(hosts: tuple[str, ...]) -> tuple[str, ...]:
    names = tuple(host.lower().strip(".") for host in hosts)
    if not names or any("." not in host for host in names):
        raise ValueError("Configure the trusted HTTPS result hostnames")
    return names


class _Provider:
    def __init__(
        self, client: httpx.AsyncClient, key: str, result_hosts: tuple[str, ...]
    ):
        if not key.strip():
            raise ValueError("Provider key is required")
        self.client = client
        self.headers = {"Authorization": f"Bearer {key.strip()}"}
        self.result_hosts = _result_hostnames(result_hosts)

    async def _request(
        self, method: str, url: str, *, submitting: bool = False, **kwargs
    ) -> dict:
        try:
            response = await self.client.request(
                method, url, follow_redirects=False, **kwargs
            )
        except httpx.RequestError as exc:
            if submitting:
                raise SubmissionUnknown() from exc
            raise _provider_error("暂时无法连接解析服务") from exc
        status = response.status_code
        if status == 429:
            raise KnowledgeError(
                "PROVIDER_RATE_LIMIT", "解析服务繁忙，请稍后重试", retryable=True
            )
        if status in {400, 401, 403, 413, 415, 422}:
            code = "PROVIDER_ACCESS" if status in {401, 403} else "PROVIDER_REJECTED"
            raise KnowledgeError(code, "解析服务拒绝请求，请检查文件或服务配置")
        if not response.is_success:
            if submitting:
                raise SubmissionUnknown()
            if status in {404, 410}:
                raise KnowledgeError(
                    "PROVIDER_JOB_EXPIRED",
                    "供应商任务已失效，可重新解析",
                    retryable=True,
                )
            raise _provider_error()
        try:
            return _object(response.json())
        except (ValueError, KnowledgeError) as exc:
            if submitting:
                raise SubmissionUnknown() from exc
            raise _provider_error() from exc

    async def _result(self, url: str) -> bytes:
        _https_url(url, self.result_hosts)
        request = self.client.build_request("GET", url)
        request.headers.pop("Authorization", None)
        request.headers.pop("Cookie", None)
        try:
            response = await self.client.send(
                request, stream=True, auth=None, follow_redirects=False
            )
            try:
                if not response.is_success:
                    raise _provider_error("解析结果暂时无法读取")
                data = bytearray()
                async for chunk in response.aiter_bytes():
                    data.extend(chunk)
                    if len(data) > MAX_PROVIDER_RESULT_BYTES:
                        raise KnowledgeError("CONTENT_TOO_LONG", "解析结果超过大小限制")
                return bytes(data)
            finally:
                await response.aclose()
        except httpx.RequestError as exc:
            raise _provider_error("解析结果暂时无法读取") from exc


def _png(content: bytes) -> bytes:
    try:
        with Image.open(
            io.BytesIO(content), formats=["JPEG", "PNG", "WEBP"]
        ) as picture:
            if picture.width * picture.height > MAX_IMAGE_PIXELS:
                raise KnowledgeError("IMAGE_LIMIT", "图片像素超过识别限制")
            frame = ImageOps.exif_transpose(picture).convert("RGB")
            with io.BytesIO() as buffer:
                frame.save(buffer, format="PNG")
                output = buffer.getvalue()
        if len(output) > 50 * MIB:
            raise KnowledgeError("IMAGE_LIMIT", "图片内容超过识别限制")
        return output
    except (OSError, Image.DecompressionBombError) as exc:
        raise KnowledgeError("INVALID_IMAGE", "无法读取图片") from exc


async def prepare_image(content: bytes) -> bytes:
    return await asyncio.to_thread(_png, content)


def _ocr_blocks(payload: bytes) -> tuple[tuple[Block, ...], int]:
    blocks: list[Block] = []
    number = 0
    try:
        for line in payload.splitlines():
            if not line.strip():
                continue
            result = _object(_object(json.loads(line)).get("result"))
            layouts = _array(result.get("layoutParsingResults"))
            pages = layouts or _array(result.get("ocrResults"))
            for page in pages:
                number += 1
                page = _object(page)
                if layouts:
                    text = _object(page.get("markdown") or {}).get("text")
                else:
                    pruned = _object(page.get("prunedResult") or {})
                    texts = pruned.get("rec_texts") or pruned.get("recTexts")
                    text = "\n".join(
                        value for value in _array(texts) if isinstance(value, str)
                    )
                if isinstance(text, str) and text.strip():
                    blocks.append(Block(text, page=number))
    except ValueError as exc:
        raise _provider_error("图片识别结果格式无效") from exc
    return tuple(blocks), number


class PaddleOCR(_Provider):
    name = "paddleocr"

    def __init__(
        self,
        client: httpx.AsyncClient,
        *,
        key: str,
        result_hosts: tuple[str, ...] = PADDLE_OCR_RESULT_HOSTS,
        base_url: str = _PADDLE_API,
        model: str = "PaddleOCR-VL-1.6",
    ):
        self.jobs = _https_url(base_url.rstrip("/")) + "/api/v2/ocr/jobs"
        self._official = httpx.URL(self.jobs) == httpx.URL(_PADDLE_API + "/api/v2/ocr/jobs")
        super().__init__(client, key, _BOS_ENDPOINTS if self._official else result_hosts)
        self.model = model

    async def prepare(self, claim: Claim, content: bytes, request_key: str) -> bytes:
        if _is_pdf(content):
            # Scanned PDFs are sent whole: the provider returns one layout result per
            # page, which keeps page numbers aligned with the original document.
            if len(content) > INTAKE.ocr_pdf_max_bytes:
                raise KnowledgeError(
                    "FILE_TOO_LARGE",
                    f"扫描版 PDF 不能超过 {INTAKE.ocr_pdf_max_bytes // MIB} MB",
                )
            return content
        return await prepare_image(content)

    async def submit(self, source: bytes | str, request_key: str) -> str:
        if not isinstance(source, bytes):
            raise KnowledgeError("INVALID_IMAGE", "无法读取图片")
        upload = (
            ("knowledge.pdf", source, "application/pdf")
            if _is_pdf(source)
            else ("knowledge.png", source, "image/png")
        )
        payload = await self._request(
            "POST",
            self.jobs,
            headers=self.headers,
            submitting=True,
            data={"model": self.model, "batchId": request_key},
            files={"file": upload},
        )
        data = payload.get("data")
        if not isinstance(data, dict) or payload.get("code", 0) not in {0, "0"}:
            raise SubmissionUnknown()
        return _job_id(data.get("jobId"))

    async def recover(self, request_key: str) -> str | None:
        payload = await self._request(
            "GET",
            f"{self.jobs}/batch/{quote(request_key, safe='')}",
            headers=self.headers,
        )
        jobs = _array(_object(payload.get("data")).get("extractResult"))
        if len(jobs) != 1:
            return None
        return _job_id(_object(jobs[0]).get("jobId"))

    async def poll(self, job_id: str) -> Parsed | None:
        try:
            _job_id(job_id)
        except SubmissionUnknown:
            raise KnowledgeError("PROVIDER_JOB_INVALID", "OCR 任务号无效") from None
        payload = await self._request(
            "GET", f"{self.jobs}/{job_id}", headers=self.headers
        )
        data = _object(payload.get("data"))
        if payload.get("code", 0) not in (0, "0") or data.get("jobId", job_id) != job_id:
            raise _provider_error("识别服务返回的任务结果与查询不符")
        state = str(data.get("state") or "").lower()
        if state in {"pending", "running"}:
            return None
        if state == "expired":
            raise KnowledgeError(
                "PROVIDER_JOB_EXPIRED", "图片识别任务已失效", retryable=True
            )
        if state in {"failed", "canceled", "cancelled"}:
            raise KnowledgeError("OCR_FAILED", "图片识别失败，请检查原件")
        if state != "done":
            raise _provider_error()
        url = _object(data.get("resultUrl")).get("jsonUrl")
        if not isinstance(url, str):
            raise _provider_error()
        blocks, page_count = _ocr_blocks(await self._result(url))
        return Parsed(f"paddleocr:{self.model}", blocks, page_count=page_count)

    async def _result(self, url: str) -> bytes:
        if not self._official:
            return await super()._result(url)

        # BOS 支持“桶名.地域域名”和“地域域名/桶名”。同一地域的桶由百度在任务回执中指定。
        try:
            parsed = urlsplit(url)
            host = parsed.hostname or ""
            port = parsed.port
        except ValueError:
            raise KnowledgeError("PROVIDER_URL_INVALID", "OCR 结果下载地址被拒绝（未知域名）") from None
        bucket, _, endpoint = host.partition(".")
        regional_bucket = endpoint in self.result_hosts and re.fullmatch(r"[a-z0-9][a-z0-9-]{0,61}[a-z0-9]", bucket)
        try:
            if port not in (None, 443) or parsed.fragment or not (host in self.result_hosts or regional_bucket):
                raise LinkReadError("unsafe_url")
            return (await read_public_link(url, _BOS_DOWNLOAD)).body
        except LinkReadError as exc:
            if exc.code == "response_too_large":
                raise KnowledgeError("CONTENT_TOO_LONG", "解析结果超过大小限制") from None
            if exc.code in {"invalid_url", "unsupported_url", "unsafe_url", "unsafe_address", "too_many_redirects"}:
                label = host if re.fullmatch(r"[a-zA-Z0-9.:-]{1,253}", host) else "未知域名"
                raise KnowledgeError("PROVIDER_URL_INVALID", f"OCR 结果下载地址被拒绝（{label}）") from None
            raise _provider_error("OCR 结果暂时无法读取，可续查原任务") from None


async def _probe_duration(source: Path, ffprobe: str) -> float | None:
    """Read the real duration so the limit is expressed in seconds, not bytes.

    A byte cap alone silently cuts long recordings: 64 kbps mono reaches the size
    limit at a fixed minute count, and ``ffmpeg -fs`` just stops writing. Probing
    first lets the caller reject the file with its actual length instead.
    """
    try:
        process = await asyncio.create_subprocess_exec(
            ffprobe,
            "-v",
            "error",
            "-protocol_whitelist",
            "file,pipe",
            "-show_entries",
            "format=duration",
            "-of",
            "default=noprint_wrappers=1:nokey=1",
            str(source),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
    except FileNotFoundError:
        return None
    try:
        stdout, _ = await process.communicate()
    finally:
        if process.returncode is None:
            try:
                process.kill()
            except ProcessLookupError:
                pass
            await process.wait()
    try:
        seconds = float((stdout or b"").decode(errors="replace").strip())
    except ValueError:
        return None
    return seconds if math.isfinite(seconds) and seconds > 0 else None


def _duration_label(seconds: float) -> str:
    total = int(round(seconds))
    hours, remainder = divmod(total, 3600)
    minutes, remainder = divmod(remainder, 60)
    if hours and minutes:
        return f"{hours} 小时 {minutes} 分"
    if hours:
        return f"{hours} 小时"
    if minutes:
        return f"{minutes} 分钟"
    return f"{max(1, remainder)} 秒"


def _ffprobe_path(ffmpeg: str, ffprobe: str) -> str:
    # A host that pins ffmpeg to an absolute path usually has ffprobe next to it
    # and not on PATH, so derive it instead of silently losing the duration check.
    if ffprobe:
        return ffprobe
    return (
        str(Path(ffmpeg).with_name("ffprobe"))
        if PurePath(ffmpeg).parent.name
        else "ffprobe"
    )


async def probe_media_seconds(
    content: bytes, filename: str, *, ffmpeg: str = "ffmpeg", ffprobe: str = ""
) -> float | None:
    """Return duration in seconds without transcoding.

    Upload entry points call this so an over-long recording is rejected before
    it is stored and before an ASR job is paid for. ``None`` means ffprobe could
    not decide (missing binary or unparsable header); the callers then fall back
    to the byte cap instead of blocking the upload.
    """
    with TemporaryDirectory(prefix="lc-knowledge-probe-") as folder:
        source = Path(folder) / ("input" + PurePath(filename).suffix.lower())
        await asyncio.to_thread(source.write_bytes, content)
        return await _probe_duration(source, _ffprobe_path(ffmpeg, ffprobe))


def ensure_media_duration(seconds: float | None) -> None:
    """Raise a non-retryable error when a probed recording exceeds the limit."""
    if seconds is not None and seconds > MAX_ASR_SECONDS:
        raise KnowledgeError(
            "MEDIA_TOO_LONG",
            f"音视频时长 {_duration_label(seconds)}，超过单份"
            f" {_duration_label(MAX_ASR_SECONDS)} 上限，请剪取片段后再上传",
        )


async def prepare_audio(
    content: bytes, filename: str, *, ffmpeg: str = "ffmpeg", ffprobe: str = ""
) -> bytes:
    """Decode accepted containers to a single speech track for Paraformer."""
    ffprobe = _ffprobe_path(ffmpeg, ffprobe)
    with TemporaryDirectory(prefix="lc-knowledge-asr-") as folder:
        source = Path(folder) / ("input" + PurePath(filename).suffix.lower())
        target = Path(folder) / "speech.mp3"
        await asyncio.to_thread(source.write_bytes, content)
        ensure_media_duration(await _probe_duration(source, ffprobe))
        try:
            process = await asyncio.create_subprocess_exec(
                ffmpeg,
                "-nostdin",
                "-v",
                "error",
                "-threads",
                "1",
                "-protocol_whitelist",
                "file,pipe",
                "-i",
                str(source),
                "-map",
                "0:a:0",
                "-vn",
                "-ac",
                "1",
                "-ar",
                "16000",
                "-b:a",
                "64k",
                "-map_metadata",
                "-1",
                "-fs",
                str(MAX_ASR_INPUT + 65536),
                str(target),
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
        except FileNotFoundError as exc:
            raise KnowledgeError(
                "ASR_DEPENDENCY", "音视频解析组件未配置", retryable=True
            ) from exc
        try:
            status = await process.wait()
        finally:
            if process.returncode is None:
                try:
                    process.kill()
                except ProcessLookupError:
                    pass
                await process.wait()
        if status or not target.is_file() or target.stat().st_size <= 256:
            raise KnowledgeError("NO_AUDIO_TRACK", "无法读取语音轨道，请检查音视频文件")
        # ``-fs`` stops writing at the cap and exits 0, so an at-limit file means
        # the speech track was truncated. Accepting it would hand the provider a
        # silently shortened recording, which is exactly what we must not do.
        if target.stat().st_size >= MAX_ASR_INPUT:
            raise KnowledgeError(
                "MEDIA_TOO_LONG",
                f"音视频超过单份{_duration_label(MAX_ASR_SECONDS)}上限，请剪取片段后再上传",
            )
        return await asyncio.to_thread(target.read_bytes)


def _transcript_blocks(data: dict) -> tuple[Block, ...]:
    blocks: list[Block] = []
    for track in _array(data.get("transcripts")):
        track = _object(track)
        start = len(blocks)
        for sentence in _array(track.get("sentences")):
            sentence = _object(sentence)
            if (
                not isinstance(sentence.get("text"), str)
                or not sentence["text"].strip()
            ):
                continue
            begin, end = sentence.get("begin_time"), sentence.get("end_time")
            speaker = sentence.get("speaker_id")
            blocks.append(
                Block(
                    sentence["text"],
                    start_ms=int(begin)
                    if isinstance(begin, (int, float)) and math.isfinite(begin)
                    else None,
                    end_ms=int(end)
                    if isinstance(end, (int, float)) and math.isfinite(end)
                    else None,
                    speaker=str(speaker) if isinstance(speaker, (int, str)) else None,
                )
            )
        if (
            len(blocks) == start
            and isinstance(track.get("text"), str)
            and track["text"].strip()
        ):
            blocks.append(Block(track["text"]))
    return tuple(blocks)


class DashScopeASR(_Provider):
    name = "dashscope-asr"

    def __init__(
        self,
        client: httpx.AsyncClient,
        *,
        key: str,
        result_hosts: tuple[str, ...],
        stage_audio: StageAudio | None = None,
        base_url: str = "https://dashscope.aliyuncs.com/api/v1",
        model: str = "paraformer-v2",
        ffmpeg: str = "ffmpeg",
    ):
        super().__init__(client, key, result_hosts)
        self.base_url = _https_url(base_url.rstrip("/"))
        self.model = model
        self.stage_audio = stage_audio
        self.ffmpeg = ffmpeg

    async def prepare(self, claim: Claim, content: bytes, request_key: str) -> str:
        if self.stage_audio is None:
            raise KnowledgeError("ASR_STAGING_UNAVAILABLE", "语音临时存储未配置", retryable=True)
        speech = await prepare_audio(
            content, claim.item.original.filename, ffmpeg=self.ffmpeg
        )
        url = await self.stage_audio(claim, request_key, speech)
        return _https_url(url)

    async def submit(self, source: bytes | str, request_key: str) -> str:
        if not isinstance(source, str):
            raise KnowledgeError("PROVIDER_URL_INVALID", "解析文件地址无效")
        payload = await self._request(
            "POST",
            f"{self.base_url}/services/audio/asr/transcription",
            submitting=True,
            headers={**self.headers, "X-DashScope-Async": "enable"},
            json={
                "model": self.model,
                "input": {"file_urls": [_https_url(source)]},
                "parameters": {"channel_id": [0]},
            },
        )
        output = payload.get("output")
        if not isinstance(output, dict):
            raise SubmissionUnknown()
        return _job_id(output.get("task_id"))

    async def recover(self, request_key: str) -> str | None:
        # The configured REST API queries by returned task ID only.
        return None

    async def poll(self, job_id: str) -> Parsed | None:
        payload = await self._request(
            "GET",
            f"{self.base_url}/tasks/{quote(job_id, safe='')}",
            headers=self.headers,
        )
        output = _object(payload.get("output"))
        state = str(output.get("task_status") or "").upper()
        if state in {"PENDING", "RUNNING"}:
            return None
        if state == "EXPIRED":
            raise KnowledgeError(
                "PROVIDER_JOB_EXPIRED", "转写任务已失效", retryable=True
            )
        if state in {"FAILED", "CANCELED", "CANCELLED"}:
            raise KnowledgeError("ASR_FAILED", "语音转写失败，请检查原件")
        if state != "SUCCEEDED":
            raise _provider_error()
        results = _array(output.get("results"))
        if not results:
            raise _provider_error()
        result = _object(results[0])
        if result.get("subtask_status") != "SUCCEEDED":
            raise KnowledgeError("ASR_FAILED", "语音转写失败，请检查原件")
        url = result.get("transcription_url")
        if not isinstance(url, str):
            raise _provider_error()
        try:
            data = _object(json.loads(await self._result(url)))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise _provider_error("转写结果格式无效") from exc
        properties = data.get("properties")
        duration = (
            properties.get("original_duration_in_milliseconds")
            if isinstance(properties, dict)
            else None
        )
        seconds = (
            duration / 1000
            if isinstance(duration, (int, float)) and math.isfinite(duration) and duration >= 0
            else None
        )
        return Parsed(f"dashscope:{self.model}", _transcript_blocks(data), duration_seconds=seconds)
